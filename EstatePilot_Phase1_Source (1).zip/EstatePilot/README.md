# EstatePilot

Offline-first Android real-estate CRM built in Flutter.

## Phase 1 implemented
- Dashboard and recent activity
- Property inventory: create, edit, archive, search, filter, status, notes, owner data
- Clients: buyer/seller/investor/tenant/landlord, requirements and notes
- Leads: source, pipeline stage, temperature, linked client
- Follow-ups: today, overdue, upcoming, complete/reopen
- Local persistent JSON database in Android private app storage
- Android dialer integration
- WhatsApp integration
- Android share sheet for property summaries
- Global search across properties, clients and leads
- Luxury navy/gold UI, splash screen, responsive Material 3 layout

## Architecture
- `lib/data`: entities + local JSON persistence
- `lib/state`: single app state / business actions
- `lib/core`: theme, formatting, native Android bridge
- `lib/screens`: Phase 1 screens
- `android`: native MethodChannel for secure app-files path, dialer, WhatsApp and share

No browser wrapper is used. No third-party runtime Flutter packages are required.

## Build
Use Flutter 3.47.x stable and Android SDK installed:

```bash
flutter pub get
flutter analyze
flutter test
flutter build apk --release
```

Expected APK path:
`build/app/outputs/flutter-apk/app-release.apk`
