import 'package:estatepilot/core/formatters.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('formats PKR in lakh and crore', () {
    expect(formatPkr(8500000), 'Rs. 85 Lakh');
    expect(formatPkr(10000000), 'Rs. 1 Crore');
    expect(formatPkr(12000000), 'Rs. 1.2 Crore');
  });

  test('normalizes Pakistani mobile number for WhatsApp', () {
    expect(normalizePhone('0300-1234567'), '923001234567');
  });
}
