import 'package:estatepilot/data/models.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('property JSON round-trip preserves core fields', () {
    final property = PropertyModel(
      id: 'prop-1',
      propertyId: 'EP-001',
      society: 'B-17',
      block: 'B',
      plotNumber: '123',
      type: 'Residential Plot',
      size: '8',
      unit: 'Marla',
      purpose: 'Sale',
      status: 'Available',
      ownerDemand: 9500000,
      expectedDealPrice: 9000000,
      minimumPrice: 8800000,
      ownerName: 'Owner',
      ownerPhone: '03001234567',
      source: 'Owner Direct',
      sourceContact: '03001234567',
      roadWidth: '40 ft',
      facing: 'North',
      locationNotes: 'Near park',
      notes: 'Negotiable',
      corner: true,
      parkFacing: false,
      mainRoad: false,
      possession: true,
      electricity: true,
      gas: true,
      water: true,
      sewerage: true,
      negotiable: true,
      urgentSale: false,
      createdAt: DateTime(2026, 10, 7),
      updatedAt: DateTime(2026, 10, 7),
    );

    final restored = PropertyModel.fromJson(property.toJson());
    expect(restored.propertyId, 'EP-001');
    expect(restored.society, 'B-17');
    expect(restored.status, 'Available');
    expect(restored.ownerDemand, 9500000);
    expect(restored.expectedDealPrice, 9000000);
  });

  test('database JSON round-trip preserves collections', () {
    final db = EstatePilotDatabase(
      activities: [
        ActivityModel(
          id: 'act-1',
          title: 'Test activity',
          subtitle: 'Created during test',
          kind: 'test',
          createdAt: DateTime(2026, 10, 7),
        ),
      ],
    );

    final restored = EstatePilotDatabase.fromJson(db.toJson());
    expect(restored.activities.single.title, 'Test activity');
  });
}
