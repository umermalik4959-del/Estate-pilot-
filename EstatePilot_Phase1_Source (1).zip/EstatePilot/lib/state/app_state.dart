import 'package:flutter/material.dart';

import '../data/local_store.dart';
import '../data/models.dart';

class AppState extends ChangeNotifier {
  AppState(this._store);

  final LocalStore _store;
  EstatePilotDatabase _db = EstatePilotDatabase();
  bool _ready = false;
  String? _lastError;

  bool get ready => _ready;
  String? get lastError => _lastError;
  List<PropertyModel> get properties => List.unmodifiable(_db.properties);
  List<ClientModel> get clients => List.unmodifiable(_db.clients);
  List<LeadModel> get leads => List.unmodifiable(_db.leads);
  List<FollowUpModel> get followUps => List.unmodifiable(_db.followUps);
  List<ActivityModel> get activities {
    final items = [..._db.activities]..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return List.unmodifiable(items);
  }

  Future<void> initialize() async {
    try {
      _db = await _store.load();
      _lastError = null;
    } catch (e) {
      _lastError = 'Unable to load local data: $e';
      _db = EstatePilotDatabase();
    }
    _ready = true;
    notifyListeners();
  }

  int get totalProperties => _db.properties.where((p) => p.status != 'Archived').length;
  int countPropertyStatus(String status) => _db.properties.where((p) => p.status == status).length;
  int get activeLeads => _db.leads.where((l) => l.stage != 'Deal Closed' && l.stage != 'Lost').length;
  int get buyers => _db.clients.where((c) => c.roles.contains('Buyer')).length;
  int get sellers => _db.clients.where((c) => c.roles.contains('Seller / Owner')).length;
  int get pendingFollowUps => _db.followUps.where((f) => !f.isCompleted).length;

  List<FollowUpModel> get todayFollowUps {
    final now = DateTime.now();
    return _db.followUps.where((f) {
      final d = f.scheduledAt;
      return !f.isCompleted && d.year == now.year && d.month == now.month && d.day == now.day;
    }).toList()..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
  }

  List<FollowUpModel> get overdueFollowUps {
    final now = DateTime.now();
    return _db.followUps.where((f) => !f.isCompleted && f.scheduledAt.isBefore(now) && !_sameDay(f.scheduledAt, now)).toList()
      ..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
  }

  List<FollowUpModel> get upcomingFollowUps {
    final now = DateTime.now();
    return _db.followUps.where((f) => !f.isCompleted && f.scheduledAt.isAfter(now) && !_sameDay(f.scheduledAt, now)).toList()
      ..sort((a, b) => a.scheduledAt.compareTo(b.scheduledAt));
  }

  static bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;

  Future<void> addProperty(PropertyModel property) async {
    _db.properties.insert(0, property);
    _addActivity('Property added', '${property.propertyId} • ${property.displayLocation}', 'property');
    await _persist();
  }

  Future<void> updateProperty(PropertyModel property) async {
    final index = _db.properties.indexWhere((p) => p.id == property.id);
    if (index < 0) return;
    _db.properties[index] = property;
    _addActivity('Property updated', '${property.propertyId} • ${property.status}', 'property');
    await _persist();
  }

  Future<void> archiveProperty(String id) async {
    final index = _db.properties.indexWhere((p) => p.id == id);
    if (index < 0) return;
    final updated = _db.properties[index].copyWith(status: 'Archived');
    _db.properties[index] = updated;
    _addActivity('Property archived', updated.propertyId, 'property');
    await _persist();
  }

  Future<void> addClient(ClientModel client) async {
    _db.clients.insert(0, client);
    _addActivity('Client added', '${client.name} • ${client.roles.join(', ')}', 'client');
    await _persist();
  }

  Future<void> replaceClient(ClientModel client) async {
    final index = _db.clients.indexWhere((c) => c.id == client.id);
    if (index < 0) return;
    _db.clients[index] = client;
    _addActivity('Client updated', client.name, 'client');
    await _persist();
  }

  Future<void> addLead(LeadModel lead) async {
    _db.leads.insert(0, lead);
    _addActivity('Lead added', '${lead.name} • ${lead.source}', 'lead');
    await _persist();
  }

  Future<void> updateLeadStage(String id, String stage) async {
    final index = _db.leads.indexWhere((l) => l.id == id);
    if (index < 0) return;
    _db.leads[index] = _db.leads[index].copyWith(stage: stage);
    _addActivity('Lead stage changed', '${_db.leads[index].name} → $stage', 'lead');
    await _persist();
  }

  Future<void> updateLeadTemperature(String id, String temperature) async {
    final index = _db.leads.indexWhere((l) => l.id == id);
    if (index < 0) return;
    _db.leads[index] = _db.leads[index].copyWith(temperature: temperature);
    _addActivity('Lead score updated', '${_db.leads[index].name} → $temperature', 'lead');
    await _persist();
  }

  Future<void> addFollowUp(FollowUpModel followUp) async {
    _db.followUps.insert(0, followUp);
    _addActivity('Follow-up scheduled', '${followUp.contactName} • ${followUp.type}', 'followup');
    await _persist();
  }

  Future<void> setFollowUpCompleted(String id, bool completed) async {
    final index = _db.followUps.indexWhere((f) => f.id == id);
    if (index < 0) return;
    _db.followUps[index] = _db.followUps[index].copyWith(status: completed ? 'Completed' : 'Pending');
    _addActivity(completed ? 'Follow-up completed' : 'Follow-up reopened', _db.followUps[index].contactName, 'followup');
    await _persist();
  }

  Future<void> rescheduleFollowUp(String id, DateTime at) async {
    final index = _db.followUps.indexWhere((f) => f.id == id);
    if (index < 0) return;
    _db.followUps[index] = _db.followUps[index].copyWith(status: 'Pending', scheduledAt: at);
    _addActivity('Follow-up rescheduled', _db.followUps[index].contactName, 'followup');
    await _persist();
  }

  List<PropertyModel> searchProperties(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return properties.where((p) => p.status != 'Archived').toList();
    return _db.properties.where((p) {
      if (p.status == 'Archived') return false;
      final hay = [p.propertyId, p.society, p.block, p.plotNumber, p.type, p.size, p.ownerName, p.ownerPhone, p.status].join(' ').toLowerCase();
      return hay.contains(q);
    }).toList();
  }

  List<ClientModel> searchClients(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return clients;
    return _db.clients.where((c) {
      final hay = [c.clientId, c.name, c.phone, c.whatsapp, c.email, c.city, ...c.roles, c.preferredSociety, c.status].join(' ').toLowerCase();
      return hay.contains(q);
    }).toList();
  }

  List<LeadModel> searchLeads(String query) {
    final q = query.trim().toLowerCase();
    if (q.isEmpty) return leads;
    return _db.leads.where((l) {
      final hay = [l.leadId, l.name, l.phone, l.source, l.stage, l.temperature, l.requirement].join(' ').toLowerCase();
      return hay.contains(q);
    }).toList();
  }

  PropertyModel? propertyById(String id) {
    for (final item in _db.properties) {
      if (item.id == id) return item;
    }
    return null;
  }

  ClientModel? clientById(String id) {
    for (final item in _db.clients) {
      if (item.id == id) return item;
    }
    return null;
  }

  void _addActivity(String title, String subtitle, String kind) {
    _db.activities.add(ActivityModel(
      id: newId('A'),
      title: title,
      subtitle: subtitle,
      kind: kind,
      createdAt: DateTime.now(),
    ));
    if (_db.activities.length > 200) {
      _db.activities.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      _db.activities.removeRange(200, _db.activities.length);
    }
  }

  Future<void> _persist() async {
    notifyListeners();
    try {
      await _store.save(_db);
      _lastError = null;
    } catch (e) {
      _lastError = 'Unable to save data: $e';
      notifyListeners();
      rethrow;
    }
  }
}

class AppStateScope extends InheritedNotifier<AppState> {
  const AppStateScope({
    super.key,
    required AppState notifier,
    required super.child,
  }) : super(notifier: notifier);

  static AppState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<AppStateScope>();
    assert(scope != null, 'AppStateScope is missing');
    return scope!.notifier!;
  }
}
