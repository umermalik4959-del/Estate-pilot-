import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';

class LeadFormScreen extends StatefulWidget {
  const LeadFormScreen({super.key});

  @override
  State<LeadFormScreen> createState() => _LeadFormScreenState();
}

class _LeadFormScreenState extends State<LeadFormScreen> {
  final _formKey = GlobalKey<FormState>();
  final _name = TextEditingController();
  final _phone = TextEditingController();
  final _requirement = TextEditingController();
  final _assignedTo = TextEditingController(text: 'Me');
  final _notes = TextEditingController();
  String _clientId = '';
  String _source = 'WhatsApp';
  String _stage = 'New';
  String _temperature = 'Warm';
  bool _saving = false;

  @override
  void dispose() {
    _name.dispose();
    _phone.dispose();
    _requirement.dispose();
    _assignedTo.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final state = AppStateScope.of(context);
    final now = DateTime.now();
    final lead = LeadModel(
      id: newId('L'),
      leadId: 'LD-${(state.leads.length + 1).toString().padLeft(4, '0')}',
      clientId: _clientId,
      name: _name.text.trim(),
      phone: _phone.text.trim(),
      source: _source,
      stage: _stage,
      temperature: _temperature,
      requirement: _requirement.text.trim(),
      assignedTo: _assignedTo.text.trim(),
      notes: _notes.text.trim(),
      createdAt: now,
      updatedAt: now,
    );
    try {
      await state.addLead(lead);
      if (mounted) Navigator.pop(context, lead);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Unable to save lead: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Add Lead')),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.save_rounded),
          label: const Text('Save Lead'),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Row(children: [Icon(Icons.filter_alt_outlined, color: EstatePilotTheme.gold), SizedBox(width: 8), Text('Lead Information', style: TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy))]),
                  const SizedBox(height: 14),
                  TextFormField(controller: _name, validator: (v) => v == null || v.trim().isEmpty ? 'Lead name is required' : null, decoration: const InputDecoration(labelText: 'Name')),
                  const SizedBox(height: 10),
                  TextFormField(controller: _phone, keyboardType: TextInputType.phone, validator: (v) => v == null || v.trim().isEmpty ? 'Phone is required' : null, decoration: const InputDecoration(labelText: 'Phone')),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    initialValue: '',
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Link Existing Client (optional)'),
                    items: [
                      const DropdownMenuItem(value: '', child: Text('Not linked')),
                      ...state.clients.map((c) => DropdownMenuItem(value: c.id, child: Text('${c.name} • ${c.phone}', overflow: TextOverflow.ellipsis))),
                    ],
                    onChanged: (v) {
                      _clientId = v ?? '';
                      final c = state.clientById(_clientId);
                      if (c != null) {
                        if (_name.text.trim().isEmpty) _name.text = c.name;
                        if (_phone.text.trim().isEmpty) _phone.text = c.phone;
                      }
                    },
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: _dropdown('Source', _source, const ['Facebook', 'Instagram', 'TikTok', 'WhatsApp', 'Website', 'Referral', 'Call', 'Walk-in', 'OLX', 'Other'], (v) => setState(() => _source = v))),
                    const SizedBox(width: 10),
                    Expanded(child: _dropdown('Temperature', _temperature, const ['Hot', 'Warm', 'Cold'], (v) => setState(() => _temperature = v))),
                  ]),
                  const SizedBox(height: 10),
                  _dropdown('Pipeline Stage', _stage, const ['New', 'Contacted', 'Qualified', 'Property Sent', 'Site Visit Scheduled', 'Site Visit Completed', 'Negotiation', 'Token', 'Deal Closed', 'Lost'], (v) => setState(() => _stage = v)),
                  const SizedBox(height: 10),
                  TextFormField(controller: _requirement, minLines: 2, maxLines: 4, decoration: const InputDecoration(labelText: 'Requirement', hintText: 'e.g. 8 Marla B-17, budget 90 lakh')),
                  const SizedBox(height: 10),
                  TextFormField(controller: _assignedTo, decoration: const InputDecoration(labelText: 'Assigned To')),
                  const SizedBox(height: 10),
                  TextFormField(controller: _notes, minLines: 4, maxLines: 8, decoration: const InputDecoration(labelText: 'Notes')),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _dropdown(String label, String value, List<String> options, ValueChanged<String> onChanged) => DropdownButtonFormField<String>(
        initialValue: options.contains(value) ? value : options.first,
        isExpanded: true,
        decoration: InputDecoration(labelText: label),
        items: options.map((e) => DropdownMenuItem(value: e, child: Text(e, overflow: TextOverflow.ellipsis))).toList(),
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      );
}
