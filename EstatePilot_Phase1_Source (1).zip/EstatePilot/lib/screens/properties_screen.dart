import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'property_detail_screen.dart';
import 'property_form_screen.dart';

class PropertiesScreen extends StatefulWidget {
  const PropertiesScreen({super.key});

  @override
  State<PropertiesScreen> createState() => _PropertiesScreenState();
}

class _PropertiesScreenState extends State<PropertiesScreen> {
  final _search = TextEditingController();
  String _society = 'All';
  String _status = 'All';
  String _type = 'All';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<PropertyModel> _filtered(AppState state) {
    return state.searchProperties(_search.text).where((p) {
      if (_society != 'All' && p.society != _society) return false;
      if (_status != 'All' && p.status != _status) return false;
      if (_type != 'All' && p.type != _type) return false;
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final list = _filtered(state);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addProperty',
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PropertyFormScreen())),
        backgroundColor: EstatePilotTheme.navy,
        foregroundColor: Colors.white,
        icon: const Icon(Icons.add_rounded),
        label: const Text('Property'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
            child: Column(
              children: [
                TextField(
                  controller: _search,
                  onChanged: (_) => setState(() {}),
                  decoration: const InputDecoration(
                    prefixIcon: Icon(Icons.search_rounded),
                    hintText: 'Search ID, plot, block, owner…',
                  ),
                ),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: [
                      _filter('Society', _society, const ['All', 'B-17', 'FMC', 'Faisal Hills'], (v) => setState(() => _society = v)),
                      const SizedBox(width: 8),
                      _filter('Status', _status, const ['All', 'Available', 'Hold', 'Reserved', 'Sold', 'Rented', 'Unavailable'], (v) => setState(() => _status = v)),
                      const SizedBox(width: 8),
                      _filter('Type', _type, const ['All', 'Residential Plot', 'Commercial Plot', 'House', 'Apartment', 'Shop', 'Office', 'Other'], (v) => setState(() => _type = v)),
                    ],
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: list.isEmpty
                ? EmptyState(
                    icon: Icons.home_work_outlined,
                    title: state.totalProperties == 0 ? 'No properties added yet' : 'No properties match these filters',
                    message: state.totalProperties == 0
                        ? 'Add your B-17, FMC or Faisal Hills inventory to start managing it.'
                        : 'Change search text or filters to see more inventory.',
                    actionLabel: state.totalProperties == 0 ? 'Add Property' : null,
                    onAction: state.totalProperties == 0
                        ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const PropertyFormScreen()))
                        : null,
                  )
                : ListView.separated(
                    padding: const EdgeInsets.fromLTRB(16, 2, 16, 90),
                    itemCount: list.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 9),
                    itemBuilder: (context, i) => _card(context, list[i]),
                  ),
          ),
        ],
      ),
    );
  }

  Widget _filter(String label, String value, List<String> values, ValueChanged<String> onChanged) {
    return PopupMenuButton<String>(
      initialValue: value,
      onSelected: onChanged,
      itemBuilder: (_) => values.map((e) => PopupMenuItem(value: e, child: Text(e))).toList(),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(
          color: Colors.white,
          border: Border.all(color: EstatePilotTheme.line),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('$label: $value', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
            const SizedBox(width: 5),
            const Icon(Icons.expand_more_rounded, size: 17),
          ],
        ),
      ),
    );
  }

  Widget _card(BuildContext context, PropertyModel p) {
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailScreen(propertyId: p.id))),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 48,
                    height: 48,
                    decoration: BoxDecoration(
                      color: EstatePilotTheme.navy,
                      borderRadius: BorderRadius.circular(15),
                    ),
                    child: const Icon(Icons.home_work_rounded, color: EstatePilotTheme.gold),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('${p.propertyId} • ${p.size} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
                        const SizedBox(height: 3),
                        Text(p.displayLocation, style: const TextStyle(color: Colors.black54, fontSize: 12)),
                      ],
                    ),
                  ),
                  StatusBadge(p.status),
                ],
              ),
              const SizedBox(height: 13),
              Row(
                children: [
                  Expanded(child: _mini(Icons.category_outlined, p.type)),
                  const SizedBox(width: 8),
                  Expanded(child: _mini(Icons.payments_outlined, formatPkr(p.displayPrice))),
                ],
              ),
              if (p.corner || p.parkFacing || p.mainRoad || p.possession) ...[
                const SizedBox(height: 10),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    if (p.corner) const _Feature('Corner'),
                    if (p.parkFacing) const _Feature('Park Facing'),
                    if (p.mainRoad) const _Feature('Main Road'),
                    if (p.possession) const _Feature('Possession'),
                  ],
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _mini(IconData icon, String text) {
    return Row(
      children: [
        Icon(icon, size: 15, color: EstatePilotTheme.gold),
        const SizedBox(width: 5),
        Expanded(child: Text(text, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w700))),
      ],
    );
  }
}

class _Feature extends StatelessWidget {
  const _Feature(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: EstatePilotTheme.gold.withValues(alpha: .08),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(text, style: const TextStyle(fontSize: 10, fontWeight: FontWeight.w700, color: EstatePilotTheme.navy)),
    );
  }
}
