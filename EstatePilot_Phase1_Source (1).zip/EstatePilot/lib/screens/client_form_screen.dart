import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';

class ClientFormScreen extends StatefulWidget {
  const ClientFormScreen({super.key, this.initial});
  final ClientModel? initial;

  @override
  State<ClientFormScreen> createState() => _ClientFormScreenState();
}

class _ClientFormScreenState extends State<ClientFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _name;
  late final TextEditingController _phone;
  late final TextEditingController _whatsapp;
  late final TextEditingController _email;
  late final TextEditingController _city;
  late final TextEditingController _budgetMin;
  late final TextEditingController _budgetMax;
  late final TextEditingController _preferredSize;
  late final TextEditingController _notes;

  final List<String> _roles = [];
  final List<String> _preferences = [];
  String _society = 'B-17';
  String _type = 'Residential Plot';
  String _purpose = 'Investment';
  String _timeline = 'Flexible';
  String _source = 'Referral';
  String _status = 'Active';
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    final c = widget.initial;
    _name = TextEditingController(text: c?.name ?? '');
    _phone = TextEditingController(text: c?.phone ?? '');
    _whatsapp = TextEditingController(text: c?.whatsapp ?? '');
    _email = TextEditingController(text: c?.email ?? '');
    _city = TextEditingController(text: c?.city ?? 'Islamabad');
    _budgetMin = TextEditingController(text: c == null || c.budgetMin == 0 ? '' : c.budgetMin.toStringAsFixed(0));
    _budgetMax = TextEditingController(text: c == null || c.budgetMax == 0 ? '' : c.budgetMax.toStringAsFixed(0));
    _preferredSize = TextEditingController(text: c?.preferredSize ?? '');
    _notes = TextEditingController(text: c?.notes ?? '');
    _roles.addAll(c?.roles ?? const ['Buyer']);
    _preferences.addAll(c?.preferences ?? const []);
    if (c != null) {
      _society = c.preferredSociety.isEmpty ? 'B-17' : c.preferredSociety;
      _type = c.preferredPropertyType.isEmpty ? 'Residential Plot' : c.preferredPropertyType;
      _purpose = c.purpose.isEmpty ? 'Investment' : c.purpose;
      _timeline = c.timeline;
      _source = c.source;
      _status = c.status;
    }
  }

  @override
  void dispose() {
    for (final c in [_name, _phone, _whatsapp, _email, _city, _budgetMin, _budgetMax, _preferredSize, _notes]) {
      c.dispose();
    }
    super.dispose();
  }

  double _parseMoney(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '').trim()) ?? 0;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    if (_roles.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Select at least one client role.')));
      return;
    }
    setState(() => _saving = true);
    final state = AppStateScope.of(context);
    final now = DateTime.now();
    final autoId = 'CL-${(state.clients.length + 1).toString().padLeft(4, '0')}';
    final c = ClientModel(
      id: widget.initial?.id ?? newId('C'),
      clientId: widget.initial?.clientId ?? autoId,
      name: _name.text.trim(),
      phone: _phone.text.trim(),
      whatsapp: _whatsapp.text.trim().isEmpty ? _phone.text.trim() : _whatsapp.text.trim(),
      email: _email.text.trim(),
      city: _city.text.trim(),
      roles: List<String>.from(_roles),
      budgetMin: _parseMoney(_budgetMin),
      budgetMax: _parseMoney(_budgetMax),
      preferredSociety: _society,
      preferredPropertyType: _type,
      preferredSize: _preferredSize.text.trim(),
      purpose: _purpose,
      timeline: _timeline,
      preferences: List<String>.from(_preferences),
      source: _source,
      status: _status,
      notes: _notes.text.trim(),
      createdAt: widget.initial?.createdAt ?? now,
      updatedAt: now,
    );
    try {
      if (widget.initial == null) {
        await state.addClient(c);
      } else {
        await state.replaceClient(c);
      }
      if (mounted) Navigator.pop(context, c);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Unable to save client: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.initial == null ? 'Add Client' : 'Edit Client')),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.save_rounded),
          label: Text(widget.initial == null ? 'Save Client' : 'Save Changes'),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            _section('Basic Information', Icons.person_outline_rounded, [
              _text(_name, 'Full Name', required: true),
              Row(children: [
                Expanded(child: _text(_phone, 'Phone', required: true, keyboard: TextInputType.phone)),
                const SizedBox(width: 10),
                Expanded(child: _text(_whatsapp, 'WhatsApp', keyboard: TextInputType.phone)),
              ]),
              _text(_email, 'Email', keyboard: TextInputType.emailAddress),
              _text(_city, 'City'),
              const Text('Client Roles', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.black54)),
              Wrap(
                spacing: 7,
                runSpacing: 6,
                children: const ['Buyer', 'Seller / Owner', 'Investor', 'Tenant', 'Landlord']
                    .map((role) => FilterChip(
                          label: Text(role),
                          selected: _roles.contains(role),
                          onSelected: (selected) => setState(() {
                            selected ? _roles.add(role) : _roles.remove(role);
                          }),
                        ))
                    .toList(),
              ),
            ]),
            _section('Buyer Requirement', Icons.tune_rounded, [
              Row(children: [
                Expanded(child: _moneyField(_budgetMin, 'Budget Min')),
                const SizedBox(width: 10),
                Expanded(child: _moneyField(_budgetMax, 'Budget Max')),
              ]),
              Row(children: [
                Expanded(child: _dropdown('Preferred Society', _society, const ['B-17', 'FMC', 'Faisal Hills'], (v) => setState(() => _society = v))),
                const SizedBox(width: 10),
                Expanded(child: _dropdown('Property Type', _type, const ['Residential Plot', 'Commercial Plot', 'House', 'Apartment', 'Farmhouse', 'Shop', 'Office', 'Other'], (v) => setState(() => _type = v))),
              ]),
              _text(_preferredSize, 'Preferred Size', hint: 'e.g. 8 Marla'),
              Row(children: [
                Expanded(child: _dropdown('Purpose', _purpose, const ['Investment', 'Construction', 'Residence', 'Rental', 'Commercial', 'Resale'], (v) => setState(() => _purpose = v))),
                const SizedBox(width: 10),
                Expanded(child: _dropdown('Timeline', _timeline, const ['Immediate', '1 month', '3 months', '6 months', '1 year', 'Flexible'], (v) => setState(() => _timeline = v))),
              ]),
              const Text('Preferences', style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Colors.black54)),
              Wrap(
                spacing: 7,
                runSpacing: 6,
                children: ['Corner', 'Park Facing', 'Main Road', 'Possession', 'Developed Area'].map((pref) => FilterChip(
                      label: Text(pref),
                      selected: _preferences.contains(pref),
                      onSelected: (selected) => setState(() {
                        selected ? _preferences.add(pref) : _preferences.remove(pref);
                      }),
                    )).toList(),
              ),
            ]),
            _section('CRM', Icons.hub_outlined, [
              Row(children: [
                Expanded(child: _dropdown('Source', _source, const ['Facebook', 'Instagram', 'TikTok', 'WhatsApp', 'Website', 'Referral', 'Call', 'Walk-in', 'OLX', 'Other'], (v) => setState(() => _source = v))),
                const SizedBox(width: 10),
                Expanded(child: _dropdown('Status', _status, const ['Active', 'Inactive', 'Closed'], (v) => setState(() => _status = v))),
              ]),
              TextFormField(
                controller: _notes,
                minLines: 4,
                maxLines: 8,
                decoration: const InputDecoration(labelText: 'Notes', hintText: 'Requirements, objections, preferences, next steps…'),
              ),
            ]),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, IconData icon, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [Icon(icon, color: EstatePilotTheme.gold, size: 20), const SizedBox(width: 8), Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy))]),
          const SizedBox(height: 14),
          for (var i = 0; i < children.length; i++) ...[children[i], if (i != children.length - 1) const SizedBox(height: 10)],
        ]),
      ),
    );
  }

  Widget _text(TextEditingController controller, String label, {String? hint, bool required = false, TextInputType? keyboard}) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboard,
      validator: required ? (v) => v == null || v.trim().isEmpty ? 'Required' : null : null,
      decoration: InputDecoration(labelText: label, hintText: hint),
    );
  }

  Widget _moneyField(TextEditingController controller, String label) => TextFormField(
        controller: controller,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        decoration: InputDecoration(labelText: label, prefixText: 'Rs. '),
      );

  Widget _dropdown(String label, String value, List<String> options, ValueChanged<String> onChanged) {
    final safe = options.contains(value) ? value : options.first;
    return DropdownButtonFormField<String>(
      initialValue: safe,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: options.map((e) => DropdownMenuItem(value: e, child: Text(e, overflow: TextOverflow.ellipsis))).toList(),
      onChanged: (v) {
        if (v != null) onChanged(v);
      },
    );
  }
}
