import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';

class PropertyFormScreen extends StatefulWidget {
  const PropertyFormScreen({super.key, this.initial});
  final PropertyModel? initial;

  @override
  State<PropertyFormScreen> createState() => _PropertyFormScreenState();
}

class _PropertyFormScreenState extends State<PropertyFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _propertyId;
  late final TextEditingController _block;
  late final TextEditingController _plot;
  late final TextEditingController _size;
  late final TextEditingController _roadWidth;
  late final TextEditingController _facing;
  late final TextEditingController _ownerDemand;
  late final TextEditingController _expectedPrice;
  late final TextEditingController _minimumPrice;
  late final TextEditingController _ownerName;
  late final TextEditingController _ownerPhone;
  late final TextEditingController _sourceContact;
  late final TextEditingController _locationNotes;
  late final TextEditingController _notes;

  String _society = 'B-17';
  String _type = 'Residential Plot';
  String _unit = 'Marla';
  String _purpose = 'Sale';
  String _status = 'Available';
  String _source = 'Owner Direct';
  bool _corner = false;
  bool _parkFacing = false;
  bool _mainRoad = false;
  bool _possession = false;
  bool _electricity = false;
  bool _gas = false;
  bool _water = false;
  bool _sewerage = false;
  bool _negotiable = false;
  bool _urgentSale = false;
  bool _saving = false;

  bool get _editing => widget.initial != null;

  @override
  void initState() {
    super.initState();
    final p = widget.initial;
    _propertyId = TextEditingController(text: p?.propertyId ?? '');
    _block = TextEditingController(text: p?.block ?? '');
    _plot = TextEditingController(text: p?.plotNumber ?? '');
    _size = TextEditingController(text: p?.size ?? '');
    _roadWidth = TextEditingController(text: p?.roadWidth ?? '');
    _facing = TextEditingController(text: p?.facing ?? '');
    _ownerDemand = TextEditingController(text: p == null || p.ownerDemand == 0 ? '' : p.ownerDemand.toStringAsFixed(0));
    _expectedPrice = TextEditingController(text: p == null || p.expectedDealPrice == 0 ? '' : p.expectedDealPrice.toStringAsFixed(0));
    _minimumPrice = TextEditingController(text: p == null || p.minimumPrice == 0 ? '' : p.minimumPrice.toStringAsFixed(0));
    _ownerName = TextEditingController(text: p?.ownerName ?? '');
    _ownerPhone = TextEditingController(text: p?.ownerPhone ?? '');
    _sourceContact = TextEditingController(text: p?.sourceContact ?? '');
    _locationNotes = TextEditingController(text: p?.locationNotes ?? '');
    _notes = TextEditingController(text: p?.notes ?? '');
    if (p != null) {
      _society = p.society.isEmpty ? 'B-17' : p.society;
      _type = p.type;
      _unit = p.unit;
      _purpose = p.purpose;
      _status = p.status;
      _source = p.source;
      _corner = p.corner;
      _parkFacing = p.parkFacing;
      _mainRoad = p.mainRoad;
      _possession = p.possession;
      _electricity = p.electricity;
      _gas = p.gas;
      _water = p.water;
      _sewerage = p.sewerage;
      _negotiable = p.negotiable;
      _urgentSale = p.urgentSale;
    }
  }

  @override
  void dispose() {
    for (final c in [
      _propertyId,
      _block,
      _plot,
      _size,
      _roadWidth,
      _facing,
      _ownerDemand,
      _expectedPrice,
      _minimumPrice,
      _ownerName,
      _ownerPhone,
      _sourceContact,
      _locationNotes,
      _notes,
    ]) {
      c.dispose();
    }
    super.dispose();
  }

  double _money(TextEditingController c) => double.tryParse(c.text.replaceAll(',', '').trim()) ?? 0;

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final state = AppStateScope.of(context);
    final now = DateTime.now();
    final autoId = 'EP-${(state.properties.length + 1).toString().padLeft(4, '0')}';
    final p = PropertyModel(
      id: widget.initial?.id ?? newId('P'),
      propertyId: _propertyId.text.trim().isEmpty ? autoId : _propertyId.text.trim(),
      society: _society,
      block: _block.text.trim(),
      plotNumber: _plot.text.trim(),
      type: _type,
      size: _size.text.trim(),
      unit: _unit,
      purpose: _purpose,
      status: _status,
      ownerDemand: _money(_ownerDemand),
      expectedDealPrice: _money(_expectedPrice),
      minimumPrice: _money(_minimumPrice),
      ownerName: _ownerName.text.trim(),
      ownerPhone: _ownerPhone.text.trim(),
      source: _source,
      sourceContact: _sourceContact.text.trim(),
      roadWidth: _roadWidth.text.trim(),
      facing: _facing.text.trim(),
      locationNotes: _locationNotes.text.trim(),
      notes: _notes.text.trim(),
      corner: _corner,
      parkFacing: _parkFacing,
      mainRoad: _mainRoad,
      possession: _possession,
      electricity: _electricity,
      gas: _gas,
      water: _water,
      sewerage: _sewerage,
      negotiable: _negotiable,
      urgentSale: _urgentSale,
      createdAt: widget.initial?.createdAt ?? now,
      updatedAt: now,
    );
    try {
      if (_editing) {
        await state.updateProperty(p);
      } else {
        await state.addProperty(p);
      }
      if (mounted) Navigator.pop(context, p);
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Unable to save property: $e')));
      setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(_editing ? 'Edit Property' : 'Add Property')),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.save_rounded),
          label: Text(_editing ? 'Save Changes' : 'Save Property'),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            _section(
              'Property Information',
              Icons.home_work_outlined,
              [
                TextFormField(
                  controller: _propertyId,
                  decoration: const InputDecoration(labelText: 'Property ID', hintText: 'Auto-generated if left blank'),
                ),
                _dropdown('Society', _society, const ['B-17', 'FMC', 'Faisal Hills'], (v) => setState(() => _society = v)),
                Row(
                  children: [
                    Expanded(child: _text(_block, 'Block', required: true)),
                    const SizedBox(width: 10),
                    Expanded(child: _text(_plot, 'Plot Number')),
                  ],
                ),
                _dropdown(
                  'Property Type',
                  _type,
                  const ['Residential Plot', 'Commercial Plot', 'House', 'Apartment', 'Farmhouse', 'Shop', 'Office', 'Commercial Property', 'Other'],
                  (v) => setState(() => _type = v),
                ),
                Row(
                  children: [
                    Expanded(child: _text(_size, 'Size', required: true, keyboard: TextInputType.number)),
                    const SizedBox(width: 10),
                    Expanded(child: _dropdown('Unit', _unit, const ['Marla', 'Kanal', 'Sq Ft', 'Sq Yd', 'Other'], (v) => setState(() => _unit = v))),
                  ],
                ),
                Row(
                  children: [
                    Expanded(child: _dropdown('Purpose', _purpose, const ['Sale', 'Rent'], (v) => setState(() => _purpose = v))),
                    const SizedBox(width: 10),
                    Expanded(child: _dropdown('Status', _status, const ['Available', 'Hold', 'Reserved', 'Sold', 'Rented', 'Unavailable', 'Archived'], (v) => setState(() => _status = v))),
                  ],
                ),
              ],
            ),
            _section(
              'Location & Features',
              Icons.pin_drop_outlined,
              [
                Row(
                  children: [
                    Expanded(child: _text(_roadWidth, 'Road Width', hint: 'e.g. 40 ft')),
                    const SizedBox(width: 10),
                    Expanded(child: _text(_facing, 'Facing', hint: 'North / South')),
                  ],
                ),
                TextFormField(
                  controller: _locationNotes,
                  minLines: 2,
                  maxLines: 4,
                  decoration: const InputDecoration(labelText: 'Location Notes', hintText: 'Near mosque, commercial, school…'),
                ),
                _switchGrid([
                  ('Corner', _corner, (v) => _corner = v),
                  ('Park Facing', _parkFacing, (v) => _parkFacing = v),
                  ('Main Road', _mainRoad, (v) => _mainRoad = v),
                  ('Possession', _possession, (v) => _possession = v),
                ]),
              ],
            ),
            _section(
              'Utilities',
              Icons.electrical_services_outlined,
              [
                _switchGrid([
                  ('Electricity', _electricity, (v) => _electricity = v),
                  ('Gas', _gas, (v) => _gas = v),
                  ('Water', _water, (v) => _water = v),
                  ('Sewerage', _sewerage, (v) => _sewerage = v),
                ]),
              ],
            ),
            _section(
              'Financial',
              Icons.account_balance_wallet_outlined,
              [
                _moneyField(_ownerDemand, 'Owner Demand'),
                _moneyField(_expectedPrice, 'Expected Deal Price'),
                _moneyField(_minimumPrice, 'Minimum Price'),
                _switchGrid([
                  ('Negotiable', _negotiable, (v) => _negotiable = v),
                  ('Urgent Sale', _urgentSale, (v) => _urgentSale = v),
                ]),
                const Padding(
                  padding: EdgeInsets.only(top: 2),
                  child: Text(
                    'Owner Demand and Expected Deal Price are stored separately.',
                    style: TextStyle(fontSize: 11.5, color: Colors.black54),
                  ),
                ),
              ],
            ),
            _section(
              'Owner & Source',
              Icons.person_pin_circle_outlined,
              [
                _text(_ownerName, 'Owner Name'),
                _text(_ownerPhone, 'Owner Phone', keyboard: TextInputType.phone),
                _dropdown('Property Source', _source, const ['Owner Direct', 'Dealer', 'Agency', 'Client', 'Referral', 'Other'], (v) => setState(() => _source = v)),
                _text(_sourceContact, 'Source Contact'),
              ],
            ),
            _section(
              'Notes',
              Icons.sticky_note_2_outlined,
              [
                TextFormField(
                  controller: _notes,
                  minLines: 4,
                  maxLines: 8,
                  decoration: const InputDecoration(hintText: 'Negotiation notes, urgency, client preference…'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, IconData icon, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 14),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(icon, color: EstatePilotTheme.gold, size: 20),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy)),
              ],
            ),
            const SizedBox(height: 14),
            for (var i = 0; i < children.length; i++) ...[
              children[i],
              if (i != children.length - 1) const SizedBox(height: 10),
            ],
          ],
        ),
      ),
    );
  }

  Widget _text(
    TextEditingController controller,
    String label, {
    String? hint,
    bool required = false,
    TextInputType? keyboard,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboard,
      validator: required ? (v) => (v == null || v.trim().isEmpty) ? 'Required' : null : null,
      decoration: InputDecoration(labelText: label, hintText: hint),
    );
  }

  Widget _moneyField(TextEditingController controller, String label) {
    return TextFormField(
      controller: controller,
      keyboardType: const TextInputType.numberWithOptions(decimal: true),
      decoration: InputDecoration(labelText: label, prefixText: 'Rs. '),
    );
  }

  Widget _dropdown(String label, String value, List<String> options, ValueChanged<String> onChanged) {
    final safe = options.contains(value) ? value : options.first;
    return DropdownButtonFormField<String>(
      initialValue: safe,
      isExpanded: true,
      decoration: InputDecoration(labelText: label),
      items: options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: (v) {
        if (v != null) onChanged(v);
      },
    );
  }

  Widget _switchGrid(List<(String, bool, ValueChanged<bool>)> items) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final itemWidth = (constraints.maxWidth - 8) / 2;
        return Wrap(
          spacing: 8,
          runSpacing: 8,
          children: items.map((item) {
            return SizedBox(
              width: itemWidth,
              child: InkWell(
                borderRadius: BorderRadius.circular(13),
                onTap: () => setState(() => item.$3(!item.$2)),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                  decoration: BoxDecoration(
                    border: Border.all(color: item.$2 ? EstatePilotTheme.gold : EstatePilotTheme.line),
                    color: item.$2 ? EstatePilotTheme.gold.withValues(alpha: .07) : Colors.white,
                    borderRadius: BorderRadius.circular(13),
                  ),
                  child: Row(
                    children: [
                      Expanded(child: Text(item.$1, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700))),
                      Switch.adaptive(
                        value: item.$2,
                        onChanged: (v) => setState(() => item.$3(v)),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        );
      },
    );
  }
}
