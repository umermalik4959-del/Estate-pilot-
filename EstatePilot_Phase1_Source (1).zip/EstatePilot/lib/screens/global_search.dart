import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'client_detail_screen.dart';
import 'property_detail_screen.dart';

class EstatePilotSearchDelegate extends SearchDelegate<void> {
  EstatePilotSearchDelegate()
      : super(
          searchFieldLabel: 'Property, client, phone, society, lead…',
          searchFieldStyle: const TextStyle(fontSize: 15),
        );

  @override
  List<Widget>? buildActions(BuildContext context) => [
        if (query.isNotEmpty)
          IconButton(onPressed: () => query = '', icon: const Icon(Icons.close_rounded)),
      ];

  @override
  Widget? buildLeading(BuildContext context) => IconButton(
        onPressed: () => close(context, null),
        icon: const Icon(Icons.arrow_back_rounded),
      );

  @override
  Widget buildResults(BuildContext context) => _build(context);

  @override
  Widget buildSuggestions(BuildContext context) => _build(context);

  Widget _build(BuildContext context) {
    final state = AppStateScope.of(context);
    final properties = state.searchProperties(query).take(8).toList();
    final clients = state.searchClients(query).take(8).toList();
    final leads = state.searchLeads(query).take(8).toList();
    if (query.trim().isEmpty) {
      return const EmptyState(
        icon: Icons.search_rounded,
        title: 'Global search',
        message: 'Search property ID, plot number, client name, phone, society, block or lead.',
      );
    }
    if (properties.isEmpty && clients.isEmpty && leads.isEmpty) {
      return const EmptyState(
        icon: Icons.manage_search_rounded,
        title: 'No matching records',
        message: 'Try a property ID, name, phone number, society or lead stage.',
      );
    }
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
      children: [
        if (properties.isNotEmpty) ...[
          const SectionTitle('Properties'),
          const SizedBox(height: 8),
          ...properties.map((p) => Card(
                child: ListTile(
                  leading: const CircleAvatar(
                    backgroundColor: Color(0xFFF2EAD5),
                    child: Icon(Icons.home_work_rounded, color: EstatePilotTheme.navy),
                  ),
                  title: Text('${p.propertyId} • ${p.size} ${p.unit}', style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${p.displayLocation}\n${formatPkr(p.displayPrice)}'),
                  isThreeLine: true,
                  trailing: StatusBadge(p.status),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyDetailScreen(propertyId: p.id))),
                ),
              )),
          const SizedBox(height: 18),
        ],
        if (clients.isNotEmpty) ...[
          const SectionTitle('Clients'),
          const SizedBox(height: 8),
          ...clients.map((c) => Card(
                child: ListTile(
                  leading: CircleAvatar(child: Text(c.name.isEmpty ? '?' : c.name[0].toUpperCase())),
                  title: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${c.phone}\n${c.roles.join(', ')}'),
                  isThreeLine: true,
                  trailing: StatusBadge(c.status),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClientDetailScreen(clientId: c.id))),
                ),
              )),
          const SizedBox(height: 18),
        ],
        if (leads.isNotEmpty) ...[
          const SectionTitle('Leads'),
          const SizedBox(height: 8),
          ...leads.map((l) => Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.filter_alt_rounded)),
                  title: Text(l.name, style: const TextStyle(fontWeight: FontWeight.w800)),
                  subtitle: Text('${l.source} • ${l.stage}\n${l.requirement}'),
                  isThreeLine: true,
                  trailing: StatusBadge(l.temperature),
                ),
              )),
        ],
      ],
    );
  }
}
