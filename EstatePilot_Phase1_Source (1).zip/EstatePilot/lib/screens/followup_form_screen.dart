import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';

class FollowUpFormScreen extends StatefulWidget {
  const FollowUpFormScreen({
    super.key,
    this.initialClientId = '',
    this.initialLeadId = '',
    this.initialPropertyId = '',
    this.initialContactName = '',
    this.initialPhone = '',
  });

  final String initialClientId;
  final String initialLeadId;
  final String initialPropertyId;
  final String initialContactName;
  final String initialPhone;

  @override
  State<FollowUpFormScreen> createState() => _FollowUpFormScreenState();
}

class _FollowUpFormScreenState extends State<FollowUpFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _title;
  late final TextEditingController _contactName;
  late final TextEditingController _phone;
  late final TextEditingController _notes;
  late String _clientId;
  late String _leadId;
  late String _propertyId;
  String _type = 'Call';
  late DateTime _scheduledAt;
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _title = TextEditingController(text: 'Follow-up');
    _contactName = TextEditingController(text: widget.initialContactName);
    _phone = TextEditingController(text: widget.initialPhone);
    _notes = TextEditingController();
    _clientId = widget.initialClientId;
    _leadId = widget.initialLeadId;
    _propertyId = widget.initialPropertyId;
    final now = DateTime.now();
    _scheduledAt = DateTime(now.year, now.month, now.day, now.hour + 1, 0);
  }

  @override
  void dispose() {
    _title.dispose();
    _contactName.dispose();
    _phone.dispose();
    _notes.dispose();
    super.dispose();
  }

  Future<void> _pickDate() async {
    final d = await showDatePicker(
      context: context,
      initialDate: _scheduledAt,
      firstDate: DateTime.now().subtract(const Duration(days: 365)),
      lastDate: DateTime.now().add(const Duration(days: 3650)),
    );
    if (d != null) setState(() => _scheduledAt = DateTime(d.year, d.month, d.day, _scheduledAt.hour, _scheduledAt.minute));
  }

  Future<void> _pickTime() async {
    final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_scheduledAt));
    if (t != null) setState(() => _scheduledAt = DateTime(_scheduledAt.year, _scheduledAt.month, _scheduledAt.day, t.hour, t.minute));
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;
    setState(() => _saving = true);
    final state = AppStateScope.of(context);
    final item = FollowUpModel(
      id: newId('F'),
      followUpId: 'FU-${(state.followUps.length + 1).toString().padLeft(4, '0')}',
      clientId: _clientId,
      leadId: _leadId,
      propertyId: _propertyId,
      title: _title.text.trim(),
      contactName: _contactName.text.trim(),
      phone: _phone.text.trim(),
      scheduledAt: _scheduledAt,
      type: _type,
      status: 'Pending',
      notes: _notes.text.trim(),
      createdAt: DateTime.now(),
    );
    try {
      await state.addFollowUp(item);
      if (mounted) Navigator.pop(context, item);
    } catch (e) {
      if (!mounted) return;
      setState(() => _saving = false);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Unable to save follow-up: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Add Follow-up')),
      bottomNavigationBar: SafeArea(
        minimum: const EdgeInsets.fromLTRB(16, 8, 16, 12),
        child: FilledButton.icon(
          onPressed: _saving ? null : _save,
          icon: _saving
              ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
              : const Icon(Icons.notification_add_rounded),
          label: const Text('Schedule Follow-up'),
        ),
      ),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 110),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  const Row(children: [Icon(Icons.notifications_active_outlined, color: EstatePilotTheme.gold), SizedBox(width: 8), Text('Follow-up Details', style: TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy))]),
                  const SizedBox(height: 14),
                  TextFormField(controller: _title, validator: (v) => v == null || v.trim().isEmpty ? 'Title is required' : null, decoration: const InputDecoration(labelText: 'Title')),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: TextFormField(controller: _contactName, validator: (v) => v == null || v.trim().isEmpty ? 'Contact name is required' : null, decoration: const InputDecoration(labelText: 'Contact Name'))),
                    const SizedBox(width: 10),
                    Expanded(child: TextFormField(controller: _phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Phone'))),
                  ]),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    initialValue: _type,
                    decoration: const InputDecoration(labelText: 'Type'),
                    items: const ['Call', 'WhatsApp', 'Meeting', 'Site Visit', 'Document', 'Negotiation'].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
                    onChanged: (v) => setState(() => _type = v ?? _type),
                  ),
                  const SizedBox(height: 10),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_today_outlined), label: Text(formatDate(_scheduledAt)))),
                    const SizedBox(width: 10),
                    Expanded(child: OutlinedButton.icon(onPressed: _pickTime, icon: const Icon(Icons.schedule_outlined), label: Text(formatTime(_scheduledAt)))),
                  ]),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    initialValue: _clientId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Client (optional)'),
                    items: [const DropdownMenuItem(value: '', child: Text('Not linked')), ...state.clients.map((c) => DropdownMenuItem(value: c.id, child: Text(c.name, overflow: TextOverflow.ellipsis)))],
                    onChanged: (v) {
                      setState(() => _clientId = v ?? '');
                      final c = state.clientById(_clientId);
                      if (c != null) {
                        _contactName.text = c.name;
                        if (_phone.text.trim().isEmpty) _phone.text = c.whatsapp.isEmpty ? c.phone : c.whatsapp;
                      }
                    },
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    initialValue: _propertyId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Property (optional)'),
                    items: [const DropdownMenuItem(value: '', child: Text('Not linked')), ...state.properties.where((p) => p.status != 'Archived').map((p) => DropdownMenuItem(value: p.id, child: Text('${p.propertyId} • ${p.society} ${p.block}', overflow: TextOverflow.ellipsis)))],
                    onChanged: (v) => setState(() => _propertyId = v ?? ''),
                  ),
                  const SizedBox(height: 10),
                  DropdownButtonFormField<String>(
                    initialValue: _leadId,
                    isExpanded: true,
                    decoration: const InputDecoration(labelText: 'Lead (optional)'),
                    items: [const DropdownMenuItem(value: '', child: Text('Not linked')), ...state.leads.map((l) => DropdownMenuItem(value: l.id, child: Text('${l.name} • ${l.stage}', overflow: TextOverflow.ellipsis)))],
                    onChanged: (v) => setState(() => _leadId = v ?? ''),
                  ),
                  const SizedBox(height: 10),
                  TextFormField(controller: _notes, minLines: 4, maxLines: 8, decoration: const InputDecoration(labelText: 'Notes', hintText: 'What should you discuss or confirm?')),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
