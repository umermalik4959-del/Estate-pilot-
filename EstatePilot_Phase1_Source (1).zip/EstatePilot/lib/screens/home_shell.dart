import 'package:flutter/material.dart';

import '../core/theme.dart';
import '../state/app_state.dart';
import 'clients_screen.dart';
import 'dashboard_screen.dart';
import 'followups_screen.dart';
import 'global_search.dart';
import 'leads_screen.dart';
import 'properties_screen.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  int _index = 0;

  late final List<Widget> _screens = [
    DashboardScreen(onNavigate: _navigate),
    const PropertiesScreen(),
    const ClientsScreen(),
    const LeadsScreen(),
    const FollowUpsScreen(),
  ];

  void _navigate(int index) {
    if (!mounted) return;
    setState(() => _index = index.clamp(0, _screens.length - 1));
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 18,
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  colors: [EstatePilotTheme.navy, EstatePilotTheme.navy2],
                ),
                borderRadius: BorderRadius.circular(13),
              ),
              child: const Icon(Icons.navigation_rounded, color: EstatePilotTheme.gold, size: 21),
            ),
            const SizedBox(width: 10),
            const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'EstatePilot',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900, color: EstatePilotTheme.navy),
                ),
                Text(
                  'Real Estate Management',
                  style: TextStyle(fontSize: 10.5, color: Colors.black54, fontWeight: FontWeight.w600),
                ),
              ],
            ),
          ],
        ),
        actions: [
          if (state.lastError != null)
            IconButton(
              tooltip: state.lastError,
              onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(state.lastError!)),
              ),
              icon: const Icon(Icons.warning_amber_rounded, color: Color(0xFFB42318)),
            ),
          IconButton(
            tooltip: 'Search',
            onPressed: () => showSearch(context: context, delegate: EstatePilotSearchDelegate()),
            icon: const Icon(Icons.search_rounded),
          ),
          const SizedBox(width: 6),
        ],
      ),
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _index,
        onDestinationSelected: _navigate,
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard_rounded), label: 'Dashboard'),
          NavigationDestination(icon: Icon(Icons.home_work_outlined), selectedIcon: Icon(Icons.home_work_rounded), label: 'Properties'),
          NavigationDestination(icon: Icon(Icons.people_alt_outlined), selectedIcon: Icon(Icons.people_alt_rounded), label: 'Clients'),
          NavigationDestination(icon: Icon(Icons.filter_alt_outlined), selectedIcon: Icon(Icons.filter_alt_rounded), label: 'Leads'),
          NavigationDestination(icon: Icon(Icons.notifications_active_outlined), selectedIcon: Icon(Icons.notifications_active_rounded), label: 'Follow-ups'),
        ],
      ),
    );
  }
}
