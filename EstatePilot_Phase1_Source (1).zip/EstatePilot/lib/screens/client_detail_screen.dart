import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/native_bridge.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'client_form_screen.dart';
import 'followup_form_screen.dart';

class ClientDetailScreen extends StatelessWidget {
  const ClientDetailScreen({super.key, required this.clientId});
  final String clientId;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final c = state.clientById(clientId);
    if (c == null) return const Scaffold(body: Center(child: Text('Client not found.')));
    final relatedFollowUps = state.followUps.where((f) => f.clientId == c.id).toList()
      ..sort((a, b) => b.scheduledAt.compareTo(a.scheduledAt));
    return Scaffold(
      appBar: AppBar(
        title: Text(c.name),
        actions: [
          IconButton(
            tooltip: 'Edit client',
            onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClientFormScreen(initial: c))),
            icon: const Icon(Icons.edit_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 34),
        children: [
          _hero(c),
          const SizedBox(height: 14),
          _actions(context, c),
          const SizedBox(height: 14),
          _section('Profile', [
            _row('Client ID', c.clientId),
            _row('Phone', c.phone),
            _row('WhatsApp', c.whatsapp),
            _row('Email', c.email),
            _row('City', c.city),
            _row('Roles', c.roles.join(', ')),
            _row('Source', c.source),
            _row('Status', c.status, trailing: StatusBadge(c.status)),
          ]),
          _section('Requirement', [
            _row('Budget', c.budgetMax > 0 ? '${formatPkr(c.budgetMin)} – ${formatPkr(c.budgetMax)}' : '—'),
            _row('Society', c.preferredSociety),
            _row('Property Type', c.preferredPropertyType),
            _row('Size', c.preferredSize),
            _row('Purpose', c.purpose),
            _row('Timeline', c.timeline),
            _row('Preferences', c.preferences.isEmpty ? '—' : c.preferences.join(', ')),
          ]),
          _section('Notes', [Text(c.notes.isEmpty ? 'No notes added.' : c.notes, style: const TextStyle(height: 1.45))]),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Row(children: [
                  const Expanded(child: Text('Client activity', style: TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy))),
                  Text('${relatedFollowUps.length} follow-ups', style: const TextStyle(fontSize: 11, color: Colors.black54)),
                ]),
                const SizedBox(height: 10),
                if (relatedFollowUps.isEmpty)
                  const Text('No linked follow-ups yet.', style: TextStyle(color: Colors.black45))
                else
                  ...relatedFollowUps.take(8).map((f) => ListTile(
                        contentPadding: EdgeInsets.zero,
                        leading: Icon(f.isCompleted ? Icons.task_alt_rounded : Icons.schedule_rounded, color: f.isCompleted ? const Color(0xFF087F5B) : EstatePilotTheme.gold),
                        title: Text(f.title, style: const TextStyle(fontWeight: FontWeight.w700)),
                        subtitle: Text('${formatDate(f.scheduledAt)} • ${formatTime(f.scheduledAt)} • ${f.type}'),
                        trailing: StatusBadge(f.status),
                      )),
              ]),
            ),
          ),
        ],
      ),
    );
  }

  Widget _hero(ClientModel c) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(gradient: const LinearGradient(colors: [EstatePilotTheme.navy, EstatePilotTheme.navy2]), borderRadius: BorderRadius.circular(24)),
      child: Row(children: [
        CircleAvatar(
          radius: 29,
          backgroundColor: Colors.white.withValues(alpha: .1),
          foregroundColor: EstatePilotTheme.gold,
          child: Text(c.name.isEmpty ? '?' : c.name[0].toUpperCase(), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
        ),
        const SizedBox(width: 14),
        Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(c.name, style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text(c.roles.join(' • '), style: const TextStyle(color: Colors.white70)),
          if (c.preferredSociety.isNotEmpty) ...[const SizedBox(height: 5), Text('${c.preferredSociety} • ${c.preferredPropertyType}', style: const TextStyle(color: EstatePilotTheme.gold, fontSize: 12, fontWeight: FontWeight.w800))],
        ])),
      ]),
    );
  }

  Widget _actions(BuildContext context, ClientModel c) {
    final whatsapp = c.whatsapp.isEmpty ? c.phone : c.whatsapp;
    final buttons = [
      _action(Icons.call_outlined, 'Call', c.phone.isEmpty ? null : () => NativeBridge.openDialer(c.phone)),
      _action(Icons.chat_outlined, 'WhatsApp', whatsapp.isEmpty ? null : () => NativeBridge.openWhatsApp(whatsapp, message: 'Assalamualaikum ${c.name}, just following up regarding the property options we discussed.')),
      _action(Icons.notification_add_outlined, 'Follow-up', () => Navigator.push(context, MaterialPageRoute(builder: (_) => FollowUpFormScreen(initialClientId: c.id, initialContactName: c.name, initialPhone: whatsapp)))),
    ];
    return Row(children: [
      for (var i = 0; i < buttons.length; i++) ...[Expanded(child: buttons[i]), if (i != buttons.length - 1) const SizedBox(width: 8)],
    ]);
  }

  Widget _action(IconData icon, String label, VoidCallback? onTap) => OutlinedButton(
        onPressed: onTap,
        child: Column(children: [Icon(icon, size: 19), const SizedBox(height: 4), Text(label, style: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800))]),
      );

  Widget _section(String title, List<Widget> children) => Card(
        margin: const EdgeInsets.only(bottom: 12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy)),
            const SizedBox(height: 12),
            for (var i = 0; i < children.length; i++) ...[children[i], if (i != children.length - 1) const Divider(height: 18)],
          ]),
        ),
      );

  Widget _row(String label, String value, {Widget? trailing}) => Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
        SizedBox(width: 110, child: Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FontWeight.w600))),
        Expanded(child: Text(value.trim().isEmpty ? '—' : value, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700))),
        if (trailing != null) ...[const SizedBox(width: 8), trailing],
      ]);
}
