import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'client_form_screen.dart';
import 'followup_form_screen.dart';
import 'lead_form_screen.dart';
import 'property_form_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key, required this.onNavigate});

  final ValueChanged<int> onNavigate;

  Future<void> _push(BuildContext context, Widget page) async {
    await Navigator.push(context, MaterialPageRoute(builder: (_) => page));
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final width = MediaQuery.sizeOf(context).width;
    final columns = width >= 900 ? 4 : width >= 600 ? 3 : 2;
    final metrics = <({String label, String value, IconData icon, bool highlight})>[
      (label: 'Total Properties', value: '${state.totalProperties}', icon: Icons.apartment_rounded, highlight: true),
      (label: 'Available', value: '${state.countPropertyStatus('Available')}', icon: Icons.check_circle_outline_rounded, highlight: false),
      (label: 'Sold', value: '${state.countPropertyStatus('Sold')}', icon: Icons.handshake_outlined, highlight: false),
      (label: 'Reserved', value: '${state.countPropertyStatus('Reserved')}', icon: Icons.bookmark_border_rounded, highlight: false),
      (label: 'Active Leads', value: '${state.activeLeads}', icon: Icons.filter_alt_rounded, highlight: false),
      (label: 'Buyers', value: '${state.buyers}', icon: Icons.person_search_rounded, highlight: false),
      (label: 'Sellers / Owners', value: '${state.sellers}', icon: Icons.person_pin_circle_outlined, highlight: false),
      (label: 'Pending Follow-ups', value: '${state.pendingFollowUps}', icon: Icons.notifications_active_outlined, highlight: false),
    ];

    return RefreshIndicator(
      onRefresh: () async {},
      child: ListView(
        padding: const EdgeInsets.fromLTRB(16, 10, 16, 28),
        children: [
          _hero(context, state),
          const SizedBox(height: 20),
          const SectionTitle('Business snapshot'),
          const SizedBox(height: 10),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: columns,
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              mainAxisExtent: 142,
            ),
            itemCount: metrics.length,
            itemBuilder: (context, i) {
              final m = metrics[i];
              return MetricCard(label: m.label, value: m.value, icon: m.icon, highlight: m.highlight);
            },
          ),
          const SizedBox(height: 22),
          const SectionTitle('Quick actions'),
          const SizedBox(height: 10),
          Wrap(
            spacing: 10,
            runSpacing: 10,
            children: [
              _action(context, Icons.add_home_work_rounded, 'Add Property', () => _push(context, const PropertyFormScreen())),
              _action(context, Icons.person_add_alt_1_rounded, 'Add Client', () => _push(context, const ClientFormScreen())),
              _action(context, Icons.add_chart_rounded, 'Add Lead', () => _push(context, const LeadFormScreen())),
              _action(context, Icons.notification_add_rounded, 'Add Follow-up', () => _push(context, const FollowUpFormScreen())),
            ],
          ),
          const SizedBox(height: 22),
          SectionTitle(
            'Attention today',
            trailing: TextButton(onPressed: () => onNavigate(4), child: const Text('View all')),
          ),
          const SizedBox(height: 10),
          if (state.todayFollowUps.isEmpty && state.overdueFollowUps.isEmpty)
            const _CompactEmpty(
              icon: Icons.task_alt_rounded,
              title: 'You are clear for now',
              text: 'Today’s and overdue follow-ups will appear here.',
            )
          else ...[
            ...state.overdueFollowUps.take(3).map((f) => _followUpTile(context, f, overdue: true)),
            ...state.todayFollowUps.take(4).map((f) => _followUpTile(context, f)),
          ],
          const SizedBox(height: 22),
          const SectionTitle('Recent activity'),
          const SizedBox(height: 10),
          if (state.activities.isEmpty)
            const _CompactEmpty(
              icon: Icons.history_rounded,
              title: 'No activity yet',
              text: 'New properties, clients, leads and follow-ups will be recorded here.',
            )
          else
            ...state.activities.take(8).map((a) => _activityTile(context, a)),
        ],
      ),
    );
  }

  Widget _hero(BuildContext context, AppState state) {
    final now = DateTime.now();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [EstatePilotTheme.navy, EstatePilotTheme.navy2],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Your real estate command center',
                  style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900, height: 1.1),
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                decoration: BoxDecoration(color: Colors.white.withValues(alpha: .1), borderRadius: BorderRadius.circular(999)),
                child: const Text('OFFLINE READY', style: TextStyle(color: EstatePilotTheme.gold, fontSize: 9, fontWeight: FontWeight.w900)),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            '${formatDate(now)} • ${state.activeLeads} active leads • ${state.pendingFollowUps} pending follow-ups',
            style: const TextStyle(color: Colors.white70, fontSize: 12.5, height: 1.5),
          ),
        ],
      ),
    );
  }

  Widget _action(BuildContext context, IconData icon, String text, VoidCallback onTap) {
    return SizedBox(
      width: (MediaQuery.sizeOf(context).width - 42) / 2,
      child: OutlinedButton.icon(
        onPressed: onTap,
        icon: Icon(icon, size: 19, color: EstatePilotTheme.gold),
        label: Text(text, style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
    );
  }

  Widget _followUpTile(BuildContext context, FollowUpModel f, {bool overdue = false}) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Container(
          width: 40,
          height: 40,
          decoration: BoxDecoration(
            color: (overdue ? const Color(0xFFC92A2A) : EstatePilotTheme.gold).withValues(alpha: .1),
            borderRadius: BorderRadius.circular(13),
          ),
          child: Icon(overdue ? Icons.schedule_rounded : Icons.notifications_none_rounded,
              color: overdue ? const Color(0xFFC92A2A) : EstatePilotTheme.navy),
        ),
        title: Text(f.contactName.isEmpty ? f.title : f.contactName, style: const TextStyle(fontWeight: FontWeight.w800)),
        subtitle: Text('${f.type} • ${overdue ? formatDate(f.scheduledAt) : formatTime(f.scheduledAt)}'),
        trailing: overdue ? const StatusBadge('Overdue') : const Icon(Icons.chevron_right_rounded),
        onTap: () => onNavigate(4),
      ),
    );
  }

  Widget _activityTile(BuildContext context, ActivityModel a) {
    IconData icon;
    switch (a.kind) {
      case 'property':
        icon = Icons.home_work_outlined;
        break;
      case 'client':
        icon = Icons.person_outline_rounded;
        break;
      case 'lead':
        icon = Icons.filter_alt_outlined;
        break;
      default:
        icon = Icons.notifications_none_rounded;
    }
    return ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 2),
      leading: CircleAvatar(
        backgroundColor: EstatePilotTheme.gold.withValues(alpha: .11),
        child: Icon(icon, size: 18, color: EstatePilotTheme.navy),
      ),
      title: Text(a.title, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
      subtitle: Text(a.subtitle, maxLines: 1, overflow: TextOverflow.ellipsis),
      trailing: Text(formatTime(a.createdAt), style: const TextStyle(fontSize: 10, color: Colors.black45)),
    );
  }
}

class _CompactEmpty extends StatelessWidget {
  const _CompactEmpty({required this.icon, required this.title, required this.text});
  final IconData icon;
  final String title;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: EstatePilotTheme.line),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundColor: EstatePilotTheme.gold.withValues(alpha: .12),
            child: Icon(icon, color: EstatePilotTheme.navy),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
                const SizedBox(height: 2),
                Text(text, style: const TextStyle(fontSize: 12, color: Colors.black54)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
