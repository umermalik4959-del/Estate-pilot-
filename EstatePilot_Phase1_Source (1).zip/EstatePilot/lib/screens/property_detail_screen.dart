import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/native_bridge.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'followup_form_screen.dart';
import 'property_form_screen.dart';

class PropertyDetailScreen extends StatelessWidget {
  const PropertyDetailScreen({super.key, required this.propertyId});
  final String propertyId;

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final p = state.propertyById(propertyId);
    if (p == null) {
      return const Scaffold(body: Center(child: Text('Property not found.')));
    }
    return Scaffold(
      appBar: AppBar(
        title: Text(p.propertyId),
        actions: [
          PopupMenuButton<String>(
            onSelected: (value) async {
              if (value == 'edit') {
                await Navigator.push(context, MaterialPageRoute(builder: (_) => PropertyFormScreen(initial: p)));
              } else if (value == 'status') {
                await _changeStatus(context, p);
              } else if (value == 'archive') {
                final ok = await confirmDialog(
                  context,
                  title: 'Archive property?',
                  message: 'This property will be removed from active inventory but kept in local records.',
                  confirmText: 'Archive',
                  destructive: true,
                );
                if (ok) {
                  await state.archiveProperty(p.id);
                  if (context.mounted) Navigator.pop(context);
                }
              }
            },
            itemBuilder: (_) => const [
              PopupMenuItem(value: 'edit', child: ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit'))),
              PopupMenuItem(value: 'status', child: ListTile(leading: Icon(Icons.swap_horiz_rounded), title: Text('Change Status'))),
              PopupMenuItem(value: 'archive', child: ListTile(leading: Icon(Icons.archive_outlined), title: Text('Archive'))),
            ],
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(16, 8, 16, 34),
        children: [
          _hero(p),
          const SizedBox(height: 14),
          _actions(context, p),
          const SizedBox(height: 14),
          _section(
            context,
            'Property details',
            [
              _row('Property ID', p.propertyId),
              _row('Society', p.society),
              _row('Block', p.block),
              _row('Plot Number', p.plotNumber),
              _row('Size', '${p.size} ${p.unit}'),
              _row('Type', p.type),
              _row('Purpose', p.purpose),
              _row('Status', p.status, trailing: StatusBadge(p.status)),
            ],
          ),
          _section(
            context,
            'Financial',
            [
              _row('Owner Demand', formatPkr(p.ownerDemand)),
              _row('Expected Deal Price', formatPkr(p.expectedDealPrice)),
              _row('Minimum Price', formatPkr(p.minimumPrice)),
              _row('Negotiable', p.negotiable ? 'Yes' : 'No'),
              _row('Urgent Sale', p.urgentSale ? 'Yes' : 'No'),
            ],
          ),
          _section(
            context,
            'Location & features',
            [
              _row('Road Width', p.roadWidth),
              _row('Facing', p.facing),
              _row('Corner', p.corner ? 'Yes' : 'No'),
              _row('Park Facing', p.parkFacing ? 'Yes' : 'No'),
              _row('Main Road', p.mainRoad ? 'Yes' : 'No'),
              _row('Possession', p.possession ? 'Yes' : 'No'),
              if (p.locationNotes.isNotEmpty) _row('Location Notes', p.locationNotes),
            ],
          ),
          _section(
            context,
            'Utilities',
            [
              _row('Electricity', p.electricity ? 'Available' : 'Not marked'),
              _row('Gas', p.gas ? 'Available' : 'Not marked'),
              _row('Water', p.water ? 'Available' : 'Not marked'),
              _row('Sewerage', p.sewerage ? 'Available' : 'Not marked'),
            ],
          ),
          _section(
            context,
            'Owner & source',
            [
              _row('Owner', p.ownerName),
              _row('Contact', p.ownerPhone),
              _row('Source', p.source),
              _row('Source Contact', p.sourceContact),
            ],
          ),
          _section(
            context,
            'Notes',
            [
              Text(
                p.notes.isEmpty ? 'No notes added.' : p.notes,
                style: TextStyle(color: p.notes.isEmpty ? Colors.black45 : Colors.black87, height: 1.45),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _hero(PropertyModel p) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: const LinearGradient(colors: [EstatePilotTheme.navy, EstatePilotTheme.navy2]),
        borderRadius: BorderRadius.circular(24),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  '${p.size} ${p.unit} ${p.type}',
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w900),
                ),
              ),
              StatusBadge(p.status),
            ],
          ),
          const SizedBox(height: 6),
          Text(p.displayLocation, style: const TextStyle(color: Colors.white70)),
          const SizedBox(height: 18),
          Text(formatPkr(p.displayPrice), style: const TextStyle(color: EstatePilotTheme.gold, fontSize: 24, fontWeight: FontWeight.w900)),
          const SizedBox(height: 3),
          const Text('Expected deal / active price', style: TextStyle(color: Colors.white60, fontSize: 10.5)),
        ],
      ),
    );
  }

  Widget _actions(BuildContext context, PropertyModel p) {
    final buttons = <Widget>[
      _action(Icons.call_outlined, 'Call', p.ownerPhone.isEmpty ? null : () => NativeBridge.openDialer(p.ownerPhone)),
      _action(Icons.chat_outlined, 'WhatsApp', p.ownerPhone.isEmpty ? null : () => NativeBridge.openWhatsApp(p.ownerPhone, message: _whatsAppMessage(p))),
      _action(Icons.share_outlined, 'Share', () => NativeBridge.shareText(_shareText(p))),
      _action(
        Icons.notification_add_outlined,
        'Follow-up',
        () => Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => FollowUpFormScreen(
              initialPropertyId: p.id,
              initialContactName: p.ownerName,
              initialPhone: p.ownerPhone,
            ),
          ),
        ),
      ),
    ];
    return Row(
      children: [
        for (var i = 0; i < buttons.length; i++) ...[
          Expanded(child: buttons[i]),
          if (i != buttons.length - 1) const SizedBox(width: 8),
        ],
      ],
    );
  }

  Widget _action(IconData icon, String label, VoidCallback? onTap) {
    return OutlinedButton(
      onPressed: onTap,
      style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 12)),
      child: Column(
        children: [
          Icon(icon, size: 19, color: onTap == null ? Colors.black26 : EstatePilotTheme.navy),
          const SizedBox(height: 4),
          Text(label, style: const TextStyle(fontSize: 10.5, fontWeight: FontWeight.w800)),
        ],
      ),
    );
  }

  Widget _section(BuildContext context, String title, List<Widget> children) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontWeight: FontWeight.w900, color: EstatePilotTheme.navy)),
            const SizedBox(height: 12),
            for (var i = 0; i < children.length; i++) ...[
              children[i],
              if (i != children.length - 1) const Divider(height: 18),
            ],
          ],
        ),
      ),
    );
  }

  Widget _row(String label, String value, {Widget? trailing}) {
    final display = value.trim().isEmpty ? '—' : value.trim();
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(width: 122, child: Text(label, style: const TextStyle(fontSize: 12, color: Colors.black54, fontWeight: FontWeight.w600))),
        Expanded(child: Text(display, style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w700))),
        if (trailing != null) ...[const SizedBox(width: 8), trailing],
      ],
    );
  }

  Future<void> _changeStatus(BuildContext context, PropertyModel p) async {
    const statuses = ['Available', 'Hold', 'Reserved', 'Sold', 'Rented', 'Unavailable', 'Archived'];
    final selected = await showModalBottomSheet<String>(
      context: context,
      showDragHandle: true,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: [
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 6, 20, 8),
              child: Text('Change property status', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            ),
            ...statuses.map((s) => ListTile(
                  leading: Icon(s == p.status ? Icons.radio_button_checked_rounded : Icons.radio_button_off_rounded),
                  title: Text(s),
                  onTap: () => Navigator.pop(context, s),
                )),
          ],
        ),
      ),
    );
    if (selected != null && selected != p.status && context.mounted) {
      await AppStateScope.of(context).updateProperty(p.copyWith(status: selected));
    }
  }

  String _whatsAppMessage(PropertyModel p) {
    return 'Assalamualaikum, I am contacting you regarding your property ${p.propertyId} in ${p.society}, ${p.block}. Please let me know a convenient time to discuss it.';
  }

  String _shareText(PropertyModel p) {
    final features = <String>[
      if (p.corner) 'Corner',
      if (p.parkFacing) 'Park Facing',
      if (p.mainRoad) 'Main Road',
      if (p.possession) 'Possession',
    ];
    return '''EstatePilot

Property ID: ${p.propertyId}
Society: ${p.society}
Block: ${p.block}
Plot: ${p.plotNumber}
Size: ${p.size} ${p.unit}
Type: ${p.type}
Location: ${p.displayLocation}
Price: ${formatPkr(p.displayPrice)}
Status: ${p.status}
Features: ${features.isEmpty ? '—' : features.join(', ')}
Contact: ${p.ownerPhone}''';
  }
}
