import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'client_detail_screen.dart';
import 'client_form_screen.dart';

class ClientsScreen extends StatefulWidget {
  const ClientsScreen({super.key});

  @override
  State<ClientsScreen> createState() => _ClientsScreenState();
}

class _ClientsScreenState extends State<ClientsScreen> {
  final _search = TextEditingController();
  String _role = 'All';
  String _society = 'All';
  String _status = 'All';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<ClientModel> _filtered(AppState state) {
    return state.searchClients(_search.text).where((c) {
      if (_role != 'All' && !c.roles.contains(_role)) return false;
      if (_society != 'All' && c.preferredSociety != _society) return false;
      if (_status != 'All' && c.status != _status) return false;
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final list = _filtered(state);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addClient',
        backgroundColor: EstatePilotTheme.navy,
        foregroundColor: Colors.white,
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClientFormScreen())),
        icon: const Icon(Icons.person_add_alt_1_rounded),
        label: const Text('Client'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
          child: Column(children: [
            TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search name, phone, email…'),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _filter('Role', _role, const ['All', 'Buyer', 'Seller / Owner', 'Investor', 'Tenant', 'Landlord'], (v) => setState(() => _role = v)),
                const SizedBox(width: 8),
                _filter('Society', _society, const ['All', 'B-17', 'FMC', 'Faisal Hills'], (v) => setState(() => _society = v)),
                const SizedBox(width: 8),
                _filter('Status', _status, const ['All', 'Active', 'Inactive', 'Closed'], (v) => setState(() => _status = v)),
              ]),
            ),
          ]),
        ),
        Expanded(
          child: list.isEmpty
              ? EmptyState(
                  icon: Icons.people_alt_outlined,
                  title: state.clients.isEmpty ? 'No clients added yet' : 'No clients match these filters',
                  message: state.clients.isEmpty ? 'Create buyer, seller, investor, tenant or landlord profiles.' : 'Try changing your search or filters.',
                  actionLabel: state.clients.isEmpty ? 'Add Client' : null,
                  onAction: state.clients.isEmpty ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const ClientFormScreen())) : null,
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 2, 16, 90),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 9),
                  itemBuilder: (context, i) => _card(context, list[i]),
                ),
        ),
      ]),
    );
  }

  Widget _filter(String label, String value, List<String> values, ValueChanged<String> onChanged) {
    return PopupMenuButton<String>(
      initialValue: value,
      onSelected: onChanged,
      itemBuilder: (_) => values.map((e) => PopupMenuItem(value: e, child: Text(e))).toList(),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
        decoration: BoxDecoration(color: Colors.white, border: Border.all(color: EstatePilotTheme.line), borderRadius: BorderRadius.circular(12)),
        child: Row(mainAxisSize: MainAxisSize.min, children: [Text('$label: $value', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)), const SizedBox(width: 5), const Icon(Icons.expand_more_rounded, size: 17)]),
      ),
    );
  }

  Widget _card(BuildContext context, ClientModel c) {
    final budget = c.budgetMax > 0 ? '${formatPkr(c.budgetMin)} – ${formatPkr(c.budgetMax)}' : 'Budget not set';
    return Card(
      child: InkWell(
        borderRadius: BorderRadius.circular(20),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => ClientDetailScreen(clientId: c.id))),
        child: Padding(
          padding: const EdgeInsets.all(15),
          child: Row(crossAxisAlignment: CrossAxisAlignment.start, children: [
            CircleAvatar(
              radius: 25,
              backgroundColor: EstatePilotTheme.navy,
              foregroundColor: EstatePilotTheme.gold,
              child: Text(c.name.isEmpty ? '?' : c.name[0].toUpperCase(), style: const TextStyle(fontWeight: FontWeight.w900)),
            ),
            const SizedBox(width: 12),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Expanded(child: Text(c.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15))), StatusBadge(c.status)]),
              const SizedBox(height: 3),
              Text(c.roles.join(' • '), style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
              const SizedBox(height: 9),
              Text('${c.preferredSociety} • ${c.preferredPropertyType} • ${c.preferredSize}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)),
              const SizedBox(height: 3),
              Text(budget, style: const TextStyle(fontSize: 11, color: Colors.black54)),
            ])),
          ]),
        ),
      ),
    );
  }
}
