import 'package:flutter/material.dart';

import '../core/native_bridge.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'followup_form_screen.dart';
import 'lead_form_screen.dart';

class LeadsScreen extends StatefulWidget {
  const LeadsScreen({super.key});

  @override
  State<LeadsScreen> createState() => _LeadsScreenState();
}

class _LeadsScreenState extends State<LeadsScreen> {
  final _search = TextEditingController();
  String _source = 'All';
  String _stage = 'All';
  String _temperature = 'All';

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  List<LeadModel> _filtered(AppState state) {
    return state.searchLeads(_search.text).where((l) {
      if (_source != 'All' && l.source != _source) return false;
      if (_stage != 'All' && l.stage != _stage) return false;
      if (_temperature != 'All' && l.temperature != _temperature) return false;
      return true;
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final list = _filtered(state);
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addLead',
        backgroundColor: EstatePilotTheme.navy,
        foregroundColor: Colors.white,
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LeadFormScreen())),
        icon: const Icon(Icons.add_chart_rounded),
        label: const Text('Lead'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 10),
          child: Column(children: [
            TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(prefixIcon: Icon(Icons.search_rounded), hintText: 'Search lead, phone, requirement…'),
            ),
            const SizedBox(height: 8),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(children: [
                _filter('Source', _source, const ['All', 'Facebook', 'Instagram', 'TikTok', 'WhatsApp', 'Website', 'Referral', 'Call', 'Walk-in', 'OLX', 'Other'], (v) => setState(() => _source = v)),
                const SizedBox(width: 8),
                _filter('Stage', _stage, const ['All', 'New', 'Contacted', 'Qualified', 'Property Sent', 'Site Visit Scheduled', 'Site Visit Completed', 'Negotiation', 'Token', 'Deal Closed', 'Lost'], (v) => setState(() => _stage = v)),
                const SizedBox(width: 8),
                _filter('Score', _temperature, const ['All', 'Hot', 'Warm', 'Cold'], (v) => setState(() => _temperature = v)),
              ]),
            ),
          ]),
        ),
        Expanded(
          child: list.isEmpty
              ? EmptyState(
                  icon: Icons.filter_alt_outlined,
                  title: state.leads.isEmpty ? 'No leads added yet' : 'No leads match these filters',
                  message: state.leads.isEmpty ? 'Capture incoming prospects and move them through your sales pipeline.' : 'Try changing search text or filters.',
                  actionLabel: state.leads.isEmpty ? 'Add Lead' : null,
                  onAction: state.leads.isEmpty ? () => Navigator.push(context, MaterialPageRoute(builder: (_) => const LeadFormScreen())) : null,
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(16, 2, 16, 90),
                  itemCount: list.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 9),
                  itemBuilder: (context, i) => _card(context, list[i]),
                ),
        ),
      ]),
    );
  }

  Widget _filter(String label, String value, List<String> values, ValueChanged<String> onChanged) => PopupMenuButton<String>(
        initialValue: value,
        onSelected: onChanged,
        itemBuilder: (_) => values.map((e) => PopupMenuItem(value: e, child: Text(e))).toList(),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
          decoration: BoxDecoration(color: Colors.white, border: Border.all(color: EstatePilotTheme.line), borderRadius: BorderRadius.circular(12)),
          child: Row(mainAxisSize: MainAxisSize.min, children: [Text('$label: $value', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700)), const SizedBox(width: 5), const Icon(Icons.expand_more_rounded, size: 17)]),
        ),
      );

  Widget _card(BuildContext context, LeadModel lead) {
    final state = AppStateScope.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: EstatePilotTheme.navy, borderRadius: BorderRadius.circular(14)),
              child: const Icon(Icons.filter_alt_rounded, color: EstatePilotTheme.gold),
            ),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(lead.name, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 2),
              Text('${lead.source} • ${lead.phone}', style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
            ])),
            StatusBadge(lead.temperature),
          ]),
          if (lead.requirement.isNotEmpty) ...[
            const SizedBox(height: 11),
            Text(lead.requirement, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, height: 1.35)),
          ],
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: PopupMenuButton<String>(
                initialValue: lead.stage,
                onSelected: (v) => state.updateLeadStage(lead.id, v),
                itemBuilder: (_) => const ['New', 'Contacted', 'Qualified', 'Property Sent', 'Site Visit Scheduled', 'Site Visit Completed', 'Negotiation', 'Token', 'Deal Closed', 'Lost']
                    .map((e) => PopupMenuItem(value: e, child: Text(e)))
                    .toList(),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                  decoration: BoxDecoration(color: const Color(0xFFF7F8FA), borderRadius: BorderRadius.circular(11)),
                  child: Row(children: [const Icon(Icons.account_tree_outlined, size: 16, color: EstatePilotTheme.gold), const SizedBox(width: 6), Expanded(child: Text(lead.stage, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 11.5, fontWeight: FontWeight.w800))), const Icon(Icons.expand_more_rounded, size: 17)]),
                ),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filledTonal(
              tooltip: 'Call',
              onPressed: lead.phone.isEmpty ? null : () => NativeBridge.openDialer(lead.phone),
              icon: const Icon(Icons.call_outlined, size: 19),
            ),
            const SizedBox(width: 4),
            IconButton.filledTonal(
              tooltip: 'WhatsApp',
              onPressed: lead.phone.isEmpty ? null : () => NativeBridge.openWhatsApp(lead.phone, message: 'Assalamualaikum ${lead.name}, just following up regarding your property requirement.'),
              icon: const Icon(Icons.chat_outlined, size: 19),
            ),
            const SizedBox(width: 4),
            IconButton.filledTonal(
              tooltip: 'Follow-up',
              onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => FollowUpFormScreen(initialLeadId: lead.id, initialContactName: lead.name, initialPhone: lead.phone))),
              icon: const Icon(Icons.notification_add_outlined, size: 19),
            ),
          ]),
        ]),
      ),
    );
  }
}
