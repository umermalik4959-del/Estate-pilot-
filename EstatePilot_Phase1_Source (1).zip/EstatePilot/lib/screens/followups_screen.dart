import 'package:flutter/material.dart';

import '../core/formatters.dart';
import '../core/native_bridge.dart';
import '../core/theme.dart';
import '../data/models.dart';
import '../state/app_state.dart';
import '../widgets/common.dart';
import 'followup_form_screen.dart';

class FollowUpsScreen extends StatefulWidget {
  const FollowUpsScreen({super.key});

  @override
  State<FollowUpsScreen> createState() => _FollowUpsScreenState();
}

class _FollowUpsScreenState extends State<FollowUpsScreen> with SingleTickerProviderStateMixin {
  late final TabController _tabs;

  @override
  void initState() {
    super.initState();
    _tabs = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabs.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final state = AppStateScope.of(context);
    final completed = state.followUps.where((f) => f.isCompleted).toList()..sort((a, b) => b.scheduledAt.compareTo(a.scheduledAt));
    return Scaffold(
      backgroundColor: Colors.transparent,
      floatingActionButton: FloatingActionButton.extended(
        heroTag: 'addFollowup',
        backgroundColor: EstatePilotTheme.navy,
        foregroundColor: Colors.white,
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FollowUpFormScreen())),
        icon: const Icon(Icons.notification_add_rounded),
        label: const Text('Follow-up'),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
          child: Container(
            padding: const EdgeInsets.all(4),
            decoration: BoxDecoration(color: Colors.white, border: Border.all(color: EstatePilotTheme.line), borderRadius: BorderRadius.circular(16)),
            child: TabBar(
              controller: _tabs,
              isScrollable: true,
              dividerColor: Colors.transparent,
              indicator: BoxDecoration(color: EstatePilotTheme.navy, borderRadius: BorderRadius.circular(12)),
              labelColor: Colors.white,
              unselectedLabelColor: Colors.black54,
              labelStyle: const TextStyle(fontSize: 11, fontWeight: FontWeight.w800),
              tabs: [
                Tab(text: 'Today ${state.todayFollowUps.length}'),
                Tab(text: 'Overdue ${state.overdueFollowUps.length}'),
                Tab(text: 'Upcoming ${state.upcomingFollowUps.length}'),
                Tab(text: 'Done ${completed.length}'),
              ],
            ),
          ),
        ),
        Expanded(
          child: TabBarView(
            controller: _tabs,
            children: [
              _list(context, state.todayFollowUps, 'No follow-ups today', 'Your follow-ups scheduled for today will appear here.'),
              _list(context, state.overdueFollowUps, 'Nothing overdue', 'Great — there are no overdue follow-ups.'),
              _list(context, state.upcomingFollowUps, 'No upcoming follow-ups', 'Schedule follow-ups so important clients never get missed.'),
              _list(context, completed, 'No completed follow-ups', 'Completed follow-ups will remain here as activity history.', completed: true),
            ],
          ),
        ),
      ]),
    );
  }

  Widget _list(BuildContext context, List<FollowUpModel> items, String title, String message, {bool completed = false}) {
    if (items.isEmpty) {
      return EmptyState(
        icon: completed ? Icons.task_alt_rounded : Icons.notifications_none_rounded,
        title: title,
        message: message,
        actionLabel: completed ? null : 'Add Follow-up',
        onAction: completed ? null : () => Navigator.push(context, MaterialPageRoute(builder: (_) => const FollowUpFormScreen())),
      );
    }
    return ListView.separated(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 90),
      itemCount: items.length,
      separatorBuilder: (_, __) => const SizedBox(height: 9),
      itemBuilder: (context, i) => _card(context, items[i]),
    );
  }

  Widget _card(BuildContext context, FollowUpModel f) {
    final state = AppStateScope.of(context);
    final overdue = !f.isCompleted && f.scheduledAt.isBefore(DateTime.now()) && !_sameDay(f.scheduledAt, DateTime.now());
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(15),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Container(
              width: 44,
              height: 44,
              decoration: BoxDecoration(color: (overdue ? const Color(0xFFC92A2A) : EstatePilotTheme.gold).withValues(alpha: .1), borderRadius: BorderRadius.circular(14)),
              child: Icon(_icon(f.type), color: overdue ? const Color(0xFFC92A2A) : EstatePilotTheme.navy),
            ),
            const SizedBox(width: 11),
            Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(f.contactName.isEmpty ? f.title : f.contactName, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 15)),
              const SizedBox(height: 2),
              Text('${formatDate(f.scheduledAt)} • ${formatTime(f.scheduledAt)} • ${f.type}', style: const TextStyle(fontSize: 11.5, color: Colors.black54)),
            ])),
            StatusBadge(overdue ? 'Overdue' : f.status),
          ]),
          if (f.notes.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(f.notes, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 12.5, height: 1.35)),
          ],
          const SizedBox(height: 12),
          Row(children: [
            Expanded(
              child: FilledButton.tonalIcon(
                onPressed: () => state.setFollowUpCompleted(f.id, !f.isCompleted),
                icon: Icon(f.isCompleted ? Icons.undo_rounded : Icons.task_alt_rounded, size: 18),
                label: Text(f.isCompleted ? 'Reopen' : 'Complete'),
              ),
            ),
            const SizedBox(width: 8),
            IconButton.filledTonal(
              tooltip: 'Call',
              onPressed: f.phone.isEmpty ? null : () => NativeBridge.openDialer(f.phone),
              icon: const Icon(Icons.call_outlined, size: 19),
            ),
            const SizedBox(width: 4),
            IconButton.filledTonal(
              tooltip: 'WhatsApp',
              onPressed: f.phone.isEmpty ? null : () => NativeBridge.openWhatsApp(f.phone, message: 'Assalamualaikum ${f.contactName}, just following up regarding our real estate discussion.'),
              icon: const Icon(Icons.chat_outlined, size: 19),
            ),
            const SizedBox(width: 4),
            IconButton.filledTonal(
              tooltip: 'Reschedule',
              onPressed: f.isCompleted ? null : () => _reschedule(context, f),
              icon: const Icon(Icons.update_rounded, size: 19),
            ),
          ]),
        ]),
      ),
    );
  }

  Future<void> _reschedule(BuildContext context, FollowUpModel f) async {
    final state = AppStateScope.of(context);
    final date = await showDatePicker(context: context, initialDate: f.scheduledAt.isBefore(DateTime.now()) ? DateTime.now() : f.scheduledAt, firstDate: DateTime.now().subtract(const Duration(days: 1)), lastDate: DateTime.now().add(const Duration(days: 3650)));
    if (date == null || !context.mounted) return;
    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(f.scheduledAt));
    if (time == null) return;
    await state.rescheduleFollowUp(f.id, DateTime(date.year, date.month, date.day, time.hour, time.minute));
  }

  IconData _icon(String type) {
    switch (type) {
      case 'WhatsApp':
        return Icons.chat_outlined;
      case 'Meeting':
        return Icons.groups_outlined;
      case 'Site Visit':
        return Icons.location_on_outlined;
      case 'Document':
        return Icons.description_outlined;
      case 'Negotiation':
        return Icons.handshake_outlined;
      default:
        return Icons.call_outlined;
    }
  }

  bool _sameDay(DateTime a, DateTime b) => a.year == b.year && a.month == b.month && a.day == b.day;
}
