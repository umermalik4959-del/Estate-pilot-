import 'dart:math';

String newId(String prefix) {
  final now = DateTime.now().microsecondsSinceEpoch;
  final salt = Random().nextInt(9999).toString().padLeft(4, '0');
  return '$prefix-$now-$salt';
}

DateTime _date(dynamic value) {
  if (value is String) return DateTime.tryParse(value) ?? DateTime.now();
  return DateTime.now();
}

double _number(dynamic value) {
  if (value is num) return value.toDouble();
  return double.tryParse('$value') ?? 0;
}

bool _bool(dynamic value) => value == true || value == 1 || value == 'true';

class PropertyModel {
  const PropertyModel({
    required this.id,
    required this.propertyId,
    required this.society,
    required this.block,
    required this.plotNumber,
    required this.type,
    required this.size,
    required this.unit,
    required this.purpose,
    required this.status,
    required this.ownerDemand,
    required this.expectedDealPrice,
    required this.minimumPrice,
    required this.ownerName,
    required this.ownerPhone,
    required this.source,
    required this.sourceContact,
    required this.roadWidth,
    required this.facing,
    required this.locationNotes,
    required this.notes,
    required this.corner,
    required this.parkFacing,
    required this.mainRoad,
    required this.possession,
    required this.electricity,
    required this.gas,
    required this.water,
    required this.sewerage,
    required this.negotiable,
    required this.urgentSale,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String propertyId;
  final String society;
  final String block;
  final String plotNumber;
  final String type;
  final String size;
  final String unit;
  final String purpose;
  final String status;
  final double ownerDemand;
  final double expectedDealPrice;
  final double minimumPrice;
  final String ownerName;
  final String ownerPhone;
  final String source;
  final String sourceContact;
  final String roadWidth;
  final String facing;
  final String locationNotes;
  final String notes;
  final bool corner;
  final bool parkFacing;
  final bool mainRoad;
  final bool possession;
  final bool electricity;
  final bool gas;
  final bool water;
  final bool sewerage;
  final bool negotiable;
  final bool urgentSale;
  final DateTime createdAt;
  final DateTime updatedAt;

  String get displayLocation {
    final parts = [society, block, plotNumber.isEmpty ? '' : 'Plot $plotNumber']
        .where((e) => e.trim().isNotEmpty)
        .toList();
    return parts.join(' • ');
  }

  double get displayPrice => expectedDealPrice > 0 ? expectedDealPrice : ownerDemand;

  Map<String, dynamic> toJson() => {
        'id': id,
        'propertyId': propertyId,
        'society': society,
        'block': block,
        'plotNumber': plotNumber,
        'type': type,
        'size': size,
        'unit': unit,
        'purpose': purpose,
        'status': status,
        'ownerDemand': ownerDemand,
        'expectedDealPrice': expectedDealPrice,
        'minimumPrice': minimumPrice,
        'ownerName': ownerName,
        'ownerPhone': ownerPhone,
        'source': source,
        'sourceContact': sourceContact,
        'roadWidth': roadWidth,
        'facing': facing,
        'locationNotes': locationNotes,
        'notes': notes,
        'corner': corner,
        'parkFacing': parkFacing,
        'mainRoad': mainRoad,
        'possession': possession,
        'electricity': electricity,
        'gas': gas,
        'water': water,
        'sewerage': sewerage,
        'negotiable': negotiable,
        'urgentSale': urgentSale,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory PropertyModel.fromJson(Map<String, dynamic> json) => PropertyModel(
        id: '${json['id'] ?? newId('P')}',
        propertyId: '${json['propertyId'] ?? ''}',
        society: '${json['society'] ?? ''}',
        block: '${json['block'] ?? ''}',
        plotNumber: '${json['plotNumber'] ?? ''}',
        type: '${json['type'] ?? 'Residential Plot'}',
        size: '${json['size'] ?? ''}',
        unit: '${json['unit'] ?? 'Marla'}',
        purpose: '${json['purpose'] ?? 'Sale'}',
        status: '${json['status'] ?? 'Available'}',
        ownerDemand: _number(json['ownerDemand']),
        expectedDealPrice: _number(json['expectedDealPrice']),
        minimumPrice: _number(json['minimumPrice']),
        ownerName: '${json['ownerName'] ?? ''}',
        ownerPhone: '${json['ownerPhone'] ?? ''}',
        source: '${json['source'] ?? 'Owner Direct'}',
        sourceContact: '${json['sourceContact'] ?? ''}',
        roadWidth: '${json['roadWidth'] ?? ''}',
        facing: '${json['facing'] ?? ''}',
        locationNotes: '${json['locationNotes'] ?? ''}',
        notes: '${json['notes'] ?? ''}',
        corner: _bool(json['corner']),
        parkFacing: _bool(json['parkFacing']),
        mainRoad: _bool(json['mainRoad']),
        possession: _bool(json['possession']),
        electricity: _bool(json['electricity']),
        gas: _bool(json['gas']),
        water: _bool(json['water']),
        sewerage: _bool(json['sewerage']),
        negotiable: _bool(json['negotiable']),
        urgentSale: _bool(json['urgentSale']),
        createdAt: _date(json['createdAt']),
        updatedAt: _date(json['updatedAt']),
      );

  PropertyModel copyWith({
    String? propertyId,
    String? society,
    String? block,
    String? plotNumber,
    String? type,
    String? size,
    String? unit,
    String? purpose,
    String? status,
    double? ownerDemand,
    double? expectedDealPrice,
    double? minimumPrice,
    String? ownerName,
    String? ownerPhone,
    String? source,
    String? sourceContact,
    String? roadWidth,
    String? facing,
    String? locationNotes,
    String? notes,
    bool? corner,
    bool? parkFacing,
    bool? mainRoad,
    bool? possession,
    bool? electricity,
    bool? gas,
    bool? water,
    bool? sewerage,
    bool? negotiable,
    bool? urgentSale,
  }) {
    return PropertyModel(
      id: id,
      propertyId: propertyId ?? this.propertyId,
      society: society ?? this.society,
      block: block ?? this.block,
      plotNumber: plotNumber ?? this.plotNumber,
      type: type ?? this.type,
      size: size ?? this.size,
      unit: unit ?? this.unit,
      purpose: purpose ?? this.purpose,
      status: status ?? this.status,
      ownerDemand: ownerDemand ?? this.ownerDemand,
      expectedDealPrice: expectedDealPrice ?? this.expectedDealPrice,
      minimumPrice: minimumPrice ?? this.minimumPrice,
      ownerName: ownerName ?? this.ownerName,
      ownerPhone: ownerPhone ?? this.ownerPhone,
      source: source ?? this.source,
      sourceContact: sourceContact ?? this.sourceContact,
      roadWidth: roadWidth ?? this.roadWidth,
      facing: facing ?? this.facing,
      locationNotes: locationNotes ?? this.locationNotes,
      notes: notes ?? this.notes,
      corner: corner ?? this.corner,
      parkFacing: parkFacing ?? this.parkFacing,
      mainRoad: mainRoad ?? this.mainRoad,
      possession: possession ?? this.possession,
      electricity: electricity ?? this.electricity,
      gas: gas ?? this.gas,
      water: water ?? this.water,
      sewerage: sewerage ?? this.sewerage,
      negotiable: negotiable ?? this.negotiable,
      urgentSale: urgentSale ?? this.urgentSale,
      createdAt: createdAt,
      updatedAt: DateTime.now(),
    );
  }
}

class ClientModel {
  const ClientModel({
    required this.id,
    required this.clientId,
    required this.name,
    required this.phone,
    required this.whatsapp,
    required this.email,
    required this.city,
    required this.roles,
    required this.budgetMin,
    required this.budgetMax,
    required this.preferredSociety,
    required this.preferredPropertyType,
    required this.preferredSize,
    required this.purpose,
    required this.timeline,
    required this.preferences,
    required this.source,
    required this.status,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String clientId;
  final String name;
  final String phone;
  final String whatsapp;
  final String email;
  final String city;
  final List<String> roles;
  final double budgetMin;
  final double budgetMax;
  final String preferredSociety;
  final String preferredPropertyType;
  final String preferredSize;
  final String purpose;
  final String timeline;
  final List<String> preferences;
  final String source;
  final String status;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'clientId': clientId,
        'name': name,
        'phone': phone,
        'whatsapp': whatsapp,
        'email': email,
        'city': city,
        'roles': roles,
        'budgetMin': budgetMin,
        'budgetMax': budgetMax,
        'preferredSociety': preferredSociety,
        'preferredPropertyType': preferredPropertyType,
        'preferredSize': preferredSize,
        'purpose': purpose,
        'timeline': timeline,
        'preferences': preferences,
        'source': source,
        'status': status,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory ClientModel.fromJson(Map<String, dynamic> json) => ClientModel(
        id: '${json['id'] ?? newId('C')}',
        clientId: '${json['clientId'] ?? ''}',
        name: '${json['name'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        whatsapp: '${json['whatsapp'] ?? ''}',
        email: '${json['email'] ?? ''}',
        city: '${json['city'] ?? ''}',
        roles: (json['roles'] as List? ?? const ['Buyer']).map((e) => '$e').toList(),
        budgetMin: _number(json['budgetMin']),
        budgetMax: _number(json['budgetMax']),
        preferredSociety: '${json['preferredSociety'] ?? ''}',
        preferredPropertyType: '${json['preferredPropertyType'] ?? ''}',
        preferredSize: '${json['preferredSize'] ?? ''}',
        purpose: '${json['purpose'] ?? ''}',
        timeline: '${json['timeline'] ?? 'Flexible'}',
        preferences: (json['preferences'] as List? ?? const []).map((e) => '$e').toList(),
        source: '${json['source'] ?? 'Referral'}',
        status: '${json['status'] ?? 'Active'}',
        notes: '${json['notes'] ?? ''}',
        createdAt: _date(json['createdAt']),
        updatedAt: _date(json['updatedAt']),
      );
}

class LeadModel {
  const LeadModel({
    required this.id,
    required this.leadId,
    required this.clientId,
    required this.name,
    required this.phone,
    required this.source,
    required this.stage,
    required this.temperature,
    required this.requirement,
    required this.assignedTo,
    required this.notes,
    required this.createdAt,
    required this.updatedAt,
  });

  final String id;
  final String leadId;
  final String clientId;
  final String name;
  final String phone;
  final String source;
  final String stage;
  final String temperature;
  final String requirement;
  final String assignedTo;
  final String notes;
  final DateTime createdAt;
  final DateTime updatedAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'leadId': leadId,
        'clientId': clientId,
        'name': name,
        'phone': phone,
        'source': source,
        'stage': stage,
        'temperature': temperature,
        'requirement': requirement,
        'assignedTo': assignedTo,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
        'updatedAt': updatedAt.toIso8601String(),
      };

  factory LeadModel.fromJson(Map<String, dynamic> json) => LeadModel(
        id: '${json['id'] ?? newId('L')}',
        leadId: '${json['leadId'] ?? ''}',
        clientId: '${json['clientId'] ?? ''}',
        name: '${json['name'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        source: '${json['source'] ?? 'WhatsApp'}',
        stage: '${json['stage'] ?? 'New'}',
        temperature: '${json['temperature'] ?? 'Warm'}',
        requirement: '${json['requirement'] ?? ''}',
        assignedTo: '${json['assignedTo'] ?? 'Me'}',
        notes: '${json['notes'] ?? ''}',
        createdAt: _date(json['createdAt']),
        updatedAt: _date(json['updatedAt']),
      );

  LeadModel copyWith({String? stage, String? temperature}) => LeadModel(
        id: id,
        leadId: leadId,
        clientId: clientId,
        name: name,
        phone: phone,
        source: source,
        stage: stage ?? this.stage,
        temperature: temperature ?? this.temperature,
        requirement: requirement,
        assignedTo: assignedTo,
        notes: notes,
        createdAt: createdAt,
        updatedAt: DateTime.now(),
      );
}

class FollowUpModel {
  const FollowUpModel({
    required this.id,
    required this.followUpId,
    required this.clientId,
    required this.leadId,
    required this.propertyId,
    required this.title,
    required this.contactName,
    required this.phone,
    required this.scheduledAt,
    required this.type,
    required this.status,
    required this.notes,
    required this.createdAt,
  });

  final String id;
  final String followUpId;
  final String clientId;
  final String leadId;
  final String propertyId;
  final String title;
  final String contactName;
  final String phone;
  final DateTime scheduledAt;
  final String type;
  final String status;
  final String notes;
  final DateTime createdAt;

  bool get isCompleted => status == 'Completed';

  Map<String, dynamic> toJson() => {
        'id': id,
        'followUpId': followUpId,
        'clientId': clientId,
        'leadId': leadId,
        'propertyId': propertyId,
        'title': title,
        'contactName': contactName,
        'phone': phone,
        'scheduledAt': scheduledAt.toIso8601String(),
        'type': type,
        'status': status,
        'notes': notes,
        'createdAt': createdAt.toIso8601String(),
      };

  factory FollowUpModel.fromJson(Map<String, dynamic> json) => FollowUpModel(
        id: '${json['id'] ?? newId('F')}',
        followUpId: '${json['followUpId'] ?? ''}',
        clientId: '${json['clientId'] ?? ''}',
        leadId: '${json['leadId'] ?? ''}',
        propertyId: '${json['propertyId'] ?? ''}',
        title: '${json['title'] ?? 'Follow-up'}',
        contactName: '${json['contactName'] ?? ''}',
        phone: '${json['phone'] ?? ''}',
        scheduledAt: _date(json['scheduledAt']),
        type: '${json['type'] ?? 'Call'}',
        status: '${json['status'] ?? 'Pending'}',
        notes: '${json['notes'] ?? ''}',
        createdAt: _date(json['createdAt']),
      );

  FollowUpModel copyWith({String? status, DateTime? scheduledAt}) => FollowUpModel(
        id: id,
        followUpId: followUpId,
        clientId: clientId,
        leadId: leadId,
        propertyId: propertyId,
        title: title,
        contactName: contactName,
        phone: phone,
        scheduledAt: scheduledAt ?? this.scheduledAt,
        type: type,
        status: status ?? this.status,
        notes: notes,
        createdAt: createdAt,
      );
}

class ActivityModel {
  const ActivityModel({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.kind,
    required this.createdAt,
  });

  final String id;
  final String title;
  final String subtitle;
  final String kind;
  final DateTime createdAt;

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'subtitle': subtitle,
        'kind': kind,
        'createdAt': createdAt.toIso8601String(),
      };

  factory ActivityModel.fromJson(Map<String, dynamic> json) => ActivityModel(
        id: '${json['id'] ?? newId('A')}',
        title: '${json['title'] ?? ''}',
        subtitle: '${json['subtitle'] ?? ''}',
        kind: '${json['kind'] ?? 'general'}',
        createdAt: _date(json['createdAt']),
      );
}

class EstatePilotDatabase {
  EstatePilotDatabase({
    List<PropertyModel>? properties,
    List<ClientModel>? clients,
    List<LeadModel>? leads,
    List<FollowUpModel>? followUps,
    List<ActivityModel>? activities,
  })  : properties = properties ?? <PropertyModel>[],
        clients = clients ?? <ClientModel>[],
        leads = leads ?? <LeadModel>[],
        followUps = followUps ?? <FollowUpModel>[],
        activities = activities ?? <ActivityModel>[];

  final List<PropertyModel> properties;
  final List<ClientModel> clients;
  final List<LeadModel> leads;
  final List<FollowUpModel> followUps;
  final List<ActivityModel> activities;

  Map<String, dynamic> toJson() => {
        'schemaVersion': 1,
        'properties': properties.map((e) => e.toJson()).toList(),
        'clients': clients.map((e) => e.toJson()).toList(),
        'leads': leads.map((e) => e.toJson()).toList(),
        'followUps': followUps.map((e) => e.toJson()).toList(),
        'activities': activities.map((e) => e.toJson()).toList(),
      };

  factory EstatePilotDatabase.fromJson(Map<String, dynamic> json) => EstatePilotDatabase(
        properties: (json['properties'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => PropertyModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        clients: (json['clients'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => ClientModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        leads: (json['leads'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => LeadModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        followUps: (json['followUps'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => FollowUpModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
        activities: (json['activities'] as List? ?? const [])
            .whereType<Map>()
            .map((e) => ActivityModel.fromJson(Map<String, dynamic>.from(e)))
            .toList(),
      );
}
