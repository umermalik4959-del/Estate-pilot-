import 'dart:convert';
import 'dart:io';

import '../core/native_bridge.dart';
import 'models.dart';

class LocalStore {
  static const _fileName = 'estatepilot_v1.json';
  File? _file;

  Future<File> _databaseFile() async {
    if (_file != null) return _file!;
    final path = await NativeBridge.getDataPath();
    final file = File('$path/$_fileName');
    _file = file;
    return file;
  }

  Future<EstatePilotDatabase> load() async {
    final file = await _databaseFile();
    if (!await file.exists()) return EstatePilotDatabase();
    try {
      final text = await file.readAsString();
      if (text.trim().isEmpty) return EstatePilotDatabase();
      final raw = jsonDecode(text);
      if (raw is! Map) return EstatePilotDatabase();
      return EstatePilotDatabase.fromJson(Map<String, dynamic>.from(raw));
    } catch (_) {
      final backup = File('${file.path}.corrupt-${DateTime.now().millisecondsSinceEpoch}');
      try {
        await file.copy(backup.path);
      } catch (_) {}
      return EstatePilotDatabase();
    }
  }

  Future<void> save(EstatePilotDatabase database) async {
    final file = await _databaseFile();
    final tmp = File('${file.path}.tmp');
    final encoded = const JsonEncoder.withIndent('  ').convert(database.toJson());
    await tmp.writeAsString(encoded, flush: true);
    if (await file.exists()) {
      await file.delete();
    }
    await tmp.rename(file.path);
  }
}
