import 'package:flutter/material.dart';

import 'core/theme.dart';
import 'data/local_store.dart';
import 'screens/home_shell.dart';
import 'state/app_state.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final store = LocalStore();
  final appState = AppState(store);
  await appState.initialize();
  runApp(EstatePilotApp(state: appState));
}

class EstatePilotApp extends StatelessWidget {
  const EstatePilotApp({super.key, required this.state});

  final AppState state;

  @override
  Widget build(BuildContext context) {
    return AppStateScope(
      notifier: state,
      child: MaterialApp(
        title: 'EstatePilot',
        debugShowCheckedModeBanner: false,
        theme: EstatePilotTheme.light,
        darkTheme: EstatePilotTheme.dark,
        themeMode: ThemeMode.light,
        home: const HomeShell(),
      ),
    );
  }
}
