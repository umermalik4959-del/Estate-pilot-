import 'package:flutter/services.dart';

class NativeBridge {
  static const MethodChannel _channel = MethodChannel('estatepilot/native');

  static Future<String> getDataPath() async {
    final path = await _channel.invokeMethod<String>('getDataPath');
    if (path == null || path.isEmpty) {
      throw StateError('Android app data path unavailable.');
    }
    return path;
  }

  static Future<void> openDialer(String phone) async {
    await _channel.invokeMethod<void>('openDialer', {'phone': phone});
  }

  static Future<void> openWhatsApp(String phone, {String? message}) async {
    await _channel.invokeMethod<void>('openWhatsApp', {
      'phone': phone,
      'message': message ?? '',
    });
  }

  static Future<void> shareText(String text) async {
    await _channel.invokeMethod<void>('shareText', {'text': text});
  }
}
