@echo off
setlocal
cd /d %~dp0
where flutter >nul 2>nul
if errorlevel 1 (
  echo ERROR: Flutter SDK is not on PATH. Install Flutter 3.47.x stable and Android SDK first.
  exit /b 2
)

echo == EstatePilot release build ==
flutter --version || exit /b 1
flutter doctor -v || exit /b 1
flutter pub get || exit /b 1
flutter analyze || exit /b 1
flutter test || exit /b 1
flutter build apk --release || exit /b 1
copy /Y build\app\outputs\flutter-apk\app-release.apk EstatePilot.apk >nul || exit /b 1
echo SUCCESS: %CD%\EstatePilot.apk
endlocal
