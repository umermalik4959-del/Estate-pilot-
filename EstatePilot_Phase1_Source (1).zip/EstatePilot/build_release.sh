#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"

if ! command -v flutter >/dev/null 2>&1; then
  echo "ERROR: Flutter SDK is not on PATH. Install Flutter 3.47.x stable and Android SDK first."
  exit 2
fi

echo "== EstatePilot release build =="
flutter --version
flutter doctor -v
flutter pub get
flutter analyze
flutter test
flutter build apk --release
cp build/app/outputs/flutter-apk/app-release.apk EstatePilot.apk
echo "SUCCESS: $(pwd)/EstatePilot.apk"
