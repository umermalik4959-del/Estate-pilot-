package com.estatepilot.app

import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.net.URLEncoder
import java.nio.charset.StandardCharsets

class MainActivity : FlutterActivity() {
    private val channelName = "estatepilot/native"

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channelName)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "getDataPath" -> result.success(filesDir.absolutePath)
                        "openDialer" -> {
                            val phone = call.argument<String>("phone").orEmpty()
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}")))
                            result.success(null)
                        }
                        "openWhatsApp" -> {
                            val phone = normalizePhone(call.argument<String>("phone").orEmpty())
                            val message = call.argument<String>("message").orEmpty()
                            openWhatsApp(phone, message)
                            result.success(null)
                        }
                        "shareText" -> {
                            val text = call.argument<String>("text").orEmpty()
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, text)
                            }
                            startActivity(Intent.createChooser(sendIntent, "Share property"))
                            result.success(null)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("NATIVE_ACTION_FAILED", e.message, null)
                }
            }
    }

    private fun normalizePhone(input: String): String {
        var digits = input.filter { it.isDigit() }
        if (digits.startsWith("0") && digits.length == 11) {
            digits = "92" + digits.substring(1)
        }
        return digits
    }

    private fun openWhatsApp(phone: String, message: String) {
        val encodedMessage = URLEncoder.encode(message, StandardCharsets.UTF_8.toString())
        val uri = Uri.parse("https://wa.me/$phone?text=$encodedMessage")

        val consumerIntent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.whatsapp") }
        try {
            startActivity(consumerIntent)
            return
        } catch (_: ActivityNotFoundException) {
            // Try WhatsApp Business next.
        }

        val businessIntent = Intent(Intent.ACTION_VIEW, uri).apply { setPackage("com.whatsapp.w4b") }
        try {
            startActivity(businessIntent)
            return
        } catch (_: ActivityNotFoundException) {
            // Fall through to Android's normal resolver.
        }

        startActivity(Intent(Intent.ACTION_VIEW, uri))
    }
}
