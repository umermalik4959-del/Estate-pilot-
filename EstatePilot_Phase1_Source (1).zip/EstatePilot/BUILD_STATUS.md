# EstatePilot Build Status

## Implemented in this package

Phase 1 application source is implemented for:

- Premium dashboard and business snapshot
- Property inventory with add/edit/archive, status, pricing, owner/source, features, utilities, notes
- Property search and filters
- Client CRM with multi-role profiles and buyer requirements
- Lead capture, lead sources, pipeline stages and Hot/Warm/Cold scoring
- Follow-up dashboard: Today / Overdue / Upcoming / Completed
- Follow-up completion and rescheduling
- Android dialer integration
- WhatsApp integration with pre-filled messages
- Android share sheet for property summaries
- Offline persistent local JSON storage in Android private app files
- Recent activity history
- Global search
- Native Android splash screen and branded launcher icon

## Validation completed in the current workspace

- Relative Dart imports checked: PASS
- Bracket/parenthesis structural scan across Dart + Kotlin files: PASS
- Android manifest/resources and package paths cross-checked: PASS
- No third-party runtime Flutter packages are used.

## Build limitation of this workspace

This execution workspace does not have Flutter SDK, Dart SDK, Android SDK or Gradle installed, and outbound package/toolchain downloads are unavailable from the shell. Therefore an APK cannot truthfully be claimed as compiled here.

The included build scripts perform the missing real compiler checks on a Flutter/Android toolchain and copy the successful release output to `EstatePilot.apk`.

### Windows
Double-click / run:

`BUILD_RELEASE_WINDOWS.bat`

### macOS / Linux

`./build_release.sh`

A successful run creates:

`EstatePilot.apk`
