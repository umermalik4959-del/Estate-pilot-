String formatPkr(num value) {
  final amount = value.toDouble();
  if (amount >= 10000000) {
    final crore = amount / 10000000;
    return 'Rs. ${_trim(crore)} Crore';
  }
  if (amount >= 100000) {
    final lakh = amount / 100000;
    return 'Rs. ${_trim(lakh)} Lakh';
  }
  final whole = amount.round().toString();
  final chars = whole.split('').reversed.toList();
  final out = <String>[];
  for (var i = 0; i < chars.length; i++) {
    if (i != 0 && i % 3 == 0) out.add(',');
    out.add(chars[i]);
  }
  return 'Rs. ${out.reversed.join()}';
}

String _trim(double value) {
  final text = value.toStringAsFixed(value >= 10 ? 1 : 2);
  return text.replaceFirst(RegExp(r'\.0+$'), '').replaceFirst(RegExp(r'(\.\d*[1-9])0+$'), r'$1');
}

String formatDate(DateTime date) {
  const months = <String>[
    'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
    'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'
  ];
  return '${date.day} ${months[date.month - 1]} ${date.year}';
}

String formatTime(DateTime date) {
  final hour = date.hour % 12 == 0 ? 12 : date.hour % 12;
  final minute = date.minute.toString().padLeft(2, '0');
  final suffix = date.hour >= 12 ? 'PM' : 'AM';
  return '$hour:$minute $suffix';
}

String normalizePhone(String input) {
  var digits = input.replaceAll(RegExp(r'\D'), '');
  if (digits.startsWith('0') && digits.length == 11) {
    digits = '92${digits.substring(1)}';
  }
  return digits;
}
